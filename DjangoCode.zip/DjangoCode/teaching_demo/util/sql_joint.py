def get_insert_sql(table, dict_params):
    """
    生成insert的sql语句
    @table，插入记录的表名
    @dict,插入的数据，字典
    """
    sql = 'insert into %s set ' % table
    sql += dict_to_str(dict_params)
    return sql


def get_select_sql(table, keys, conditions, is_distinct=0):
    """
    生成select的sql语句
    @table，查询记录的表名
    @key，需要查询的字段
    @conditions,插入的数据，字典
    @is_distinct,查询的数据是否不重复
    """
    if is_distinct and keys is not None:
        sql = 'select distinct %s ' % ",".join(keys)
    elif keys is not None:
        sql = 'select  %s ' % ",".join(keys)
    elif keys is None:
        sql = 'select  * '
    sql += ' from %s ' % table
    if conditions:
        sql += ' where %s ' % dict_to_str_and(conditions)
    return sql


def get_update_sql(table, value, conditions):
    """
    生成update的sql语句
    @table，查询记录的表名
    @value，dict,需要更新的字段
    @conditions,插入的数据，字典
    """
    sql = 'update %s set ' % table
    sql += dict_to_str(value)
    if conditions:
        sql += ' where %s ' % dict_to_str_and(conditions)
    return sql


def get_detele_sql(table, conditions):
    """
    生成delete的sql语句
    @table，查询记录的表名

    @conditions,插入的数据，字典
    """
    sql = 'delete from  %s  ' % table
    if conditions:
        sql += ' where %s ' % dict_to_str_and(conditions)
    return sql


def dict_to_str(dict_in):
    """
    将字典变成，key='value',key='value' 的形式
    """
    tmp_list = []
    for k, v in dict_in.items():
        # tmp = "%s = %s" % (str(k), v)
        if isinstance(v, str):
            tmp = "%s = '%s' " % (str(k), str(v))
        if isinstance(v, int):
            tmp = "%s = %s " % (str(k), v)
        tmp_list.append(' ' + tmp + ' ')
    return ','.join(tmp_list)


def dict_to_str_and(dict_in):
    """
    将字典变成，key='value' and key='value'的形式。
    """
    tmp_list = []
    for k, v in dict_in.items():
        if isinstance(v, str):
            tmp = "%s = '%s' " % (str(k), str(v))
        if isinstance(v, int):
            tmp = "%s = %s " % (str(k), v)
        tmp_list.append(' ' + tmp + ' ')
    return ' and '.join(tmp_list)


def get_sql_limit(sql, curr_page, page_size):
    tmp_list = [str(int(curr_page) - 1), page_size]
    return sql + ' limit %s' % ','.join(tmp_list)


def get_sql_in(sql, params_list):
    return sql + ' in %s' % ','.join(params_list)


def get_count_sql(table, conditions):
    """
    生成select的sql语句
    @table，查询记录的表名
    @key，需要查询的字段
    @conditions,插入的数据，字典
    @is_distinct,查询的数据是否不重复
    """
    sql = 'select  count(*) '
    sql += ' from %s ' % table
    if conditions:
        sql += ' where %s ' % dict_to_str_and(conditions)
    return sql


def get_sql_all(table):
    """
    生成查询全部的数据
    @table，查询记录的表名
    """
    sql = 'select * from  %s  ' % table
    return sql