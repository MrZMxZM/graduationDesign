from util import encryption, redis_pool


def check(token):
    if token is None or token == '':
        return None
    else:
        de_token = bytes.decode(encryption.base64_decode(bytes(token, 'UTF-8')))
        if redis_pool.get(de_token) is None:
            return None
        token_arr = str(de_token).split("_")
        if len(token_arr) == 2:
            return de_token
        else:
            return None

# print(check('MTExXzE='))
