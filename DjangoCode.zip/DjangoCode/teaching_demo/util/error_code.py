from enum import Enum, unique


class ErrorObject():
    def __init__(self, error_code, message):
        self.error_code = error_code
        self.message = message


@unique
class ErrorCode(Enum):
    # 业务错误前缀为1
    SET_NAME_DUPLICATED = ErrorObject('10000001', 'SET_NAME_DUPLICATED')
    # 密码错误
    LOGIN_PWD_FAIL = ErrorObject('10000002', '密码错误')
    # 用户不存在
    LOGIN_ACCOUNT_FAIL = ErrorObject('10000002', '用户不存在')
    # 默认字段不存在
    FIELD_NOT_EXIST = ErrorObject('10000003', 'FIELD_NOT_EXIST')
    # token失效
    TOKEN_NOT_AVAILABLE = ErrorObject('10000004', '登录失效，请重新登录')
    # 确认密码与新密码不匹配
    PASSWORD_MISMATCH = ErrorObject('10000005', '确认密码与新密码不匹配')

USER_UPLOAD = 0  # 由用户上传

ALIYUN_OSS = '1'

PRIVATE_SCOPE = '1'

FILE_READABLE = '1'
FILE_NOT_READABLE = '0'
FILE_AVAILABLE = '1'
FILE_NOT_AVAILABLE = '0'

VARIABLE_UNUSED = 0  # 不被使用的变量
VARIABLE_USED = 1  # 需要使用的变量
VARIABLE_TARGET = 3  # 作为target使用的变量

DEV_IND = 'dev_ind'
