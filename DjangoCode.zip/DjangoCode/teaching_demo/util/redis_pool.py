import redis

POOL = redis.ConnectionPool(host='127.0.0.1', port=6379, password='', db=3)


def set(key, value, seconds):
    conn = redis.Redis(connection_pool=POOL)
    conn.set(key, value, seconds)


def get(key):
    conn = redis.Redis(connection_pool=POOL)
    return conn.get(key)


set("token", 12345, 60)
print(int(get("token")))
