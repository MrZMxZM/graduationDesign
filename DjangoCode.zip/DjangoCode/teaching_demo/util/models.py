from util import sql_joint, mysql_connect


def select(table, conditions, curr_page='', page_size='', keys=None, is_distinct=0):
    sql = sql_joint.get_select_sql(table, keys=keys, conditions=conditions, is_distinct=is_distinct)
    if curr_page != '' and page_size != '':
        result = mysql_connect.fetch_all(sql_joint.get_sql_limit(sql, curr_page, page_size))
    else:
        result = mysql_connect.fetch_all(sql)
    return result


def select_in(table, conditions, params_list, keys=None, is_distinct=0):
    sql = sql_joint.get_select_sql(table, keys=keys, conditions=conditions, is_distinct=is_distinct)
    sql += sql_joint.get_detele_sql(sql, params_list)
    return mysql_connect.fetch_all(sql)


def check_dict_params(dict_req):
    dict_conditions = dict()
    for k, v in dict_req.items():
        if v != '' and v is not None:
            dict_conditions[k] = v
    return dict_conditions


def count(table, conditions):
    sql = sql_joint.get_count_sql(table, conditions=conditions)
    result = mysql_connect.fetch_all(sql)
    return result


def insert(table, dict_params):
    sql = sql_joint.get_insert_sql(table, dict_params)
    return mysql_connect.insert(sql)


def update(table, dict_value, dict_params):
    sql = sql_joint.get_update_sql(table, dict_value, dict_params)
    return mysql_connect.update(sql)


def select_one(table, conditions, keys=None, is_distinct=0):
    sql = sql_joint.get_select_sql(table, keys=keys, conditions=conditions, is_distinct=is_distinct)
    result = mysql_connect.fetch_one(sql)
    return result


def delete(table, conditions):
    sql = sql_joint.get_detele_sql(table, conditions)
    result = mysql_connect.delete(sql)
    return result


def select_all(table):
    sql = sql_joint.get_sql_all(table)
    result = mysql_connect.fetch_all(sql)
    return result
