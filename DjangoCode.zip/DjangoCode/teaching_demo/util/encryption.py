import hashlib
import base64


def md5_encrypt(param):
    m = hashlib.md5()
    m.update(param.encode("UTF-8"))

    return m.hexdigest()


def base64_encode(text):
    return base64.b64encode(text)


def base64_decode(params):
    return base64.b64decode(params)


print(base64_encode(b'111_1'))
