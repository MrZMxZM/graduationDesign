from django.http import HttpResponse
import json
import datetime


def response_error(error):
    error = error.value
    return result_response(data=None, message=error.message,
                           success=False, error_code=error.error_code)


def result_response(data=None, message=None, success=True, **kwargs):
    result = kwargs
    result['success'] = success
    result['message'] = message
    result['data'] = data
    response = HttpResponse(json.dumps(result, cls=dateEncoder))
    # response["Access-Control-Allow-Origin"] = "*"
    # response["Access-Control-Allow-Methods"] = "POST, GET, OPTIONS"
    # response["Access-Control-Max-Age"] = "1000"
    # response["Access-Control-Allow-Headers"] = "*"  # 加入这行
    response['Access-Control-Allow-Origin'] = '*'
    response['Content-Type'] = 'application/json'
    response["Access-Control-Allow-Methods"] = "GET,HEAD,OPTIONS,POST,PUT"
    response[
        "Access-Control-Allow-Headers"] = "Origin, X-Requested-With, Content-Type, Accept, Connection, User-Agent, Cookie,Cache-Control"

    return response


class dateEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime.datetime):
            return obj.strftime('%Y-%m-%d %H:%M:%S')
        elif isinstance(obj, datetime.date):
            return obj.strftime('%Y-%m-%d')
        else:
            return json.JSONEncoder.default(self, obj)
