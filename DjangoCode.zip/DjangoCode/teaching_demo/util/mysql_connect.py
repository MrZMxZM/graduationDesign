import pymysql
from util.config import Config


def connect():
    conn = Config.POOL.connection()
    cursor = conn.cursor(cursor=pymysql.cursors.DictCursor)  # 以 字典的方式 显示
    return conn, cursor


def connect_close(conn, cursor):
    cursor.close()
    conn.close()


def fetch_all(sql):
    conn, cursor = connect()

    cursor.execute(sql)
    record_list = cursor.fetchall()
    connect_close(conn, cursor)

    return record_list


def fetch_one(sql):
    conn, cursor = connect()
    cursor.execute(sql)
    result = cursor.fetchone()
    connect_close(conn, cursor)

    return result


def insert(sql):
    conn, cursor = connect()
    row = cursor.execute(sql)
    conn.commit()
    connect_close(conn, cursor)
    return row


def update(sql):
    conn, cursor = connect()
    row = cursor.execute(sql)
    conn.commit()
    connect_close(conn, cursor)
    return row


def delete(sql):
    conn, cursor = connect()
    row = cursor.execute(sql)
    conn.commit()
    connect_close(conn, cursor)
    return row