from util import models

table = "supervisor"
table1 = 'right_info'
table2 = 'role_config'

def get_supervisor_by_params(params_dict):
    return models.select(table, conditions=params_dict)


def update_by_number(dict_value, params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.update(table, dict_value, params_dict)


def insert_by_params(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.insert(table, params_dict)


def insert_right_by_params(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.insert(table1, params_dict)


def get_right_by_params(params_dict, curr_page, page_size):
    params_dict = models.check_dict_params(params_dict)
    return models.select(table1, conditions=params_dict, curr_page=curr_page, page_size=page_size)


def get_count_by_params(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.count(table1, conditions=params_dict)


def update_right_by_cou_number(dict_value, params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.update(table1, dict_value, params_dict)


def get_right_by_number(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.select_one(table1, conditions=params_dict)


def delete_right_by_number(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.delete(table1, conditions=params_dict)


def get_role_by_params(params_dict):
    return models.select(table2, conditions=params_dict)