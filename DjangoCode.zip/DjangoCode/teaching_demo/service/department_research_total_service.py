from util import models

table = "department_research_total"


def get_department_research_total_by_params(params_dict, curr_page, page_size):
    params_dict = models.check_dict_params(params_dict)
    return models.select(table, conditions=params_dict, curr_page=curr_page, page_size=page_size)


def get_count_by_params(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.count(table, conditions=params_dict)


def insert_department_research_total_by_params(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.insert(table, params_dict)


def update_department_research_total_by_number(dict_value, params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.update(table, dict_value, params_dict)


def delete_department_research_total_by_number(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.delete(table, conditions=params_dict)


def get_department_research_total_by_number(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.select_one(table, params_dict)
