from util import models

table = "student"


def get_student_by_params(params_dict, curr_page, page_size):
    params_dict = models.check_dict_params(params_dict)
    return models.select(table, conditions=params_dict, curr_page=curr_page, page_size=page_size)


def get_student_by_number_in(params_dict, params_list):
    params_dict = models.check_dict_params(params_dict)
    return models.select_in(table, conditions=params_dict, params_list=params_list)


def get_count_by_params(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.count(table, conditions=params_dict)


def insert_student_by_params(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.insert(table, params_dict)


def update_student_by_params(dict_value, params_dict):
    params_dict = models.check_dict_params(params_dict)
    dict_value = models.check_dict_params(dict_value)
    return models.update(table, dict_value, params_dict)


def get_student_by_number(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.select_one(table, params_dict)


def delete_student_by_number(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.delete(table, params_dict)


def get_student_by_classes(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.select_one(table, params_dict)
