from util import models

table = "score"


def get_score_by_params(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.select(table, conditions=params_dict)


def get_count_by_params(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.count(table, conditions=params_dict)


def get_score_by_stu_number(params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.select(table, conditions=params_dict)


def get_course_all(params_dict):
     return models.select(table="course", conditions=params_dict)


def update_score_by_stu_number(dict_value, params_dict):
    params_dict = models.check_dict_params(params_dict)
    return models.update(table, dict_value, params_dict)


def delete_score(conditions):
    return models.delete(table, conditions)


def insert_score(dict_params):
    return models.insert(table, dict_params)
