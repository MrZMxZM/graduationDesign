"""teaching_demo URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path

from web import md5_encrypt_view, student_views, \
    home_views, score_views, \
    course_views, teacher_views, tests, \
    classroom_views, department_views, research_project_views, \
    research_paper_views, perfect_course_views, competition_views,\
    teacher_research_total_views,department_research_total_views

urlpatterns = [
    # path('^admin/', admin.site.urls),
    # path('hello/word/', views.hello_word),

    # 获取密码
    path('get/pwd', md5_encrypt_view.get_pwd),
    path('pwd/update', md5_encrypt_view.update_pwd),
    path('account/add', md5_encrypt_view.add_account),
    path('right/show', md5_encrypt_view.show_account),
    path('right/detail', md5_encrypt_view.detail_right),
    path('right/delete', md5_encrypt_view.delete_right),
    path('right/update', md5_encrypt_view.update_right),
    # path('login', supervisor_views.login),
    # 登录
    path('login', home_views.login),
    # 展示学生信息
    path('student/show', student_views.get_student_data),
    path('student/add', student_views.add_student_data),
    path('student/update', student_views.update_student_data),
    path('student/by/number', student_views.get_student_by_number),
    path('student/delete', student_views.delete_student_by_number),
    # 展示成绩信息
    path('score/show', score_views.get_score_data),
    path('score/detail', score_views.get_score_data_detail),
    path('score/add', score_views.add_score_data),
    path('score/update', score_views.update_score_data),
    path('score/delete', score_views.delete_score_data),
    path('course/all', score_views.get_course_all),

    # 展示课程信息
    path('course/show', course_views.get_course_list),
    path('course/add', course_views.add_course_list),
    path('course/assign', course_views.assign_course),
    path('course/update', course_views.update_course),
    path('course/detail', course_views.detail_course),
    path('course/delete', course_views.delete_course),

    # 展示教师信息
    path('teacher/show', teacher_views.get_teacher_list),
    path('teacher/add', teacher_views.add_teacher_list),
    path('teacher/update', teacher_views.update_teacher),
    path('teacher/detail', teacher_views.detail_teacher),
    path('teacher/delete', teacher_views.delete_teacher),

    # 展示教室信息
    path('classroom/show', classroom_views.get_classroom_list),
    path('classroom/add', classroom_views.add_classroom),
    path('classroom/delete', classroom_views.delete_classroom),
    path('classroom/update', classroom_views.update_classroom),
    path('classroom/detail', classroom_views.detail_classroom),

    # 部门信息
    path('department/show', department_views.get_department_list),
    path('department/add', department_views.add_department_list),
    path('department/update', department_views.update_department),
    path('department/delete', department_views.delete_department),
    path('department/get/all', department_views.all_department),
    path('department/detail', department_views.detail_department),

    # 教研项目
    path('research_project/show', research_project_views.get_research_project_list),
    path('research_project/add', research_project_views.add_research_project_list),
    path('research_project/update', research_project_views.update_research_project),
    path('research_project/delete', research_project_views.delete_research_project),
    path('research_project/detail', research_project_views.detail_research_project),

    # 教研论文
    path('research_paper/show', research_paper_views.get_research_paper_list),
    path('research_paper/add', research_paper_views.add_research_paper),
    path('research_paper/update', research_paper_views.update_research_paper),
    path('research_paper/delete', research_paper_views.delete_research_paper),
    path('research_paper/detail', research_paper_views.detail_research_paper),

    # 优秀课
    path('perfect_course/show', perfect_course_views.get_perfect_course_list),
    path('perfect_course/add', perfect_course_views.add_perfect_course),
    path('perfect_course/update', perfect_course_views.update_perfect_course),
    path('perfect_course/delete', perfect_course_views.delete_perfect_course),
    path('perfect_course/detail', perfect_course_views.detail_perfect_course),

    # 学科竞赛
    path('competition/show', competition_views.get_competition_list),
    path('competition/add', competition_views.add_competition),
    path('competition/update', competition_views.update_competition),
    path('competition/delete', competition_views.delete_competition),
    path('competition/detail', competition_views.detail_competition),


    # 教师教研成果统计
    path('teacher_research_total/show', teacher_research_total_views.get_teacher_research_total_list),
    path('teacher_research_total/add', teacher_research_total_views.add_teacher_research_total),
    path('teacher_research_total/update', teacher_research_total_views.update_teacher_research_total),
    path('teacher_research_total/delete', teacher_research_total_views.delete_teacher_research_total),
    path('teacher_research_total/detail', teacher_research_total_views.detail_teacher_research_total),

    # 部门教研成果统计
    path('department_research_total/show', department_research_total_views.get_department_research_total_list),
    path('department_research_total/add', department_research_total_views.add_department_research_total),
    path('department_research_total/update', department_research_total_views.update_department_research_total),
    path('department_research_total/delete', department_research_total_views.delete_department_research_total),
    path('department_research_total/detail', department_research_total_views.detail_department_research_total),
]
