from rest_framework.decorators import api_view
from util import result, check_token
from service import teacher_service,department_service
from util.error_code import ErrorCode


@api_view(['GET'])
def get_teacher_list(request):
    name = request.GET.get('name')
    number = request.GET.get('number')
    gender = request.GET.get('gender')
    age = request.GET.get('age')
    education = request.GET.get('education')
    mobile = request.GET.get('mobile')
    curr_page = request.GET.get('currPage')
    page_size = request.GET.get('pageSize')
    graduate = request.GET.get('graduate')
    department_number = request.GET.get('department_number')
    department_name = request.GET.get('department_name')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['name'] = name
    dict_params['number'] = number
    dict_params['gender'] = gender
    dict_params['age'] = age
    dict_params['education'] = education
    dict_params['mobile'] = mobile
    dict_params['department_number'] = department_number
    dict_params['department_name'] = department_name
    dict_params['graduate'] = graduate
    score_dict_list = teacher_service.get_teacher_by_params(dict_params, curr_page, page_size)
    size = teacher_service.get_count_by_params(dict_params)
    size_r = int(size[0]['count(*)'])
    dict_result = dict()
    dict_result['list'] = score_dict_list
    dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['POST'])
def add_teacher_list(request):
    number = request.POST.get('number')
    name = request.POST.get('name')
    gender = request.POST.get('gender')
    age = request.POST.get('age')
    mobile = request.POST.get('mobile')
    education = request.POST.get('education')
    nation = request.POST.get('nation')
    graduate = request.POST.get('graduate')
    department_name = request.POST.get('department_name')
    title = request.POST.get('title')
    birthday = request.POST.get('birthday')
    address = request.POST.get('address')
    marital_status = request.POST.get('marital_status')
    department_name_dict=dict()
    department_name_dict['department_name']=department_name
    department=department_service.get_department_by_number(department_name_dict)
    dict_params = dict()
    dict_params['number'] = int(number) if number != '' else None
    dict_params['name'] = name
    dict_params['education'] = education
    dict_params['mobile'] = mobile
    dict_params['gender'] = gender
    dict_params['nation'] = nation
    dict_params['age'] = age
    dict_params['graduate'] = graduate
    dict_params['address'] = address
    dict_params['department_number'] = department['department_number']
    dict_params['department_name'] = department_name
    dict_params['title'] = title
    dict_params['birthday'] = birthday
    dict_params['marital_status'] = marital_status
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    teacher_service.insert_teacher_by_params(dict_params)
    return result.result_response()


@api_view(['POST'])
def update_teacher(request):
    number = request.POST.get('number')
    name = request.POST.get('name')
    gender = request.POST.get('gender')
    mobile = request.POST.get('mobile')
    graduate = request.POST.get('graduate')
    department_name = request.POST.get('department_name')
    title = request.POST.get('title')
    birthday = request.POST.get('birthday')
    department_name_dict=dict()
    department_name_dict['department_name']=department_name
    department=department_service.get_department_by_number(department_name_dict)
    dict_value = dict()
    dict_value['number'] = int(number) if number != '' else None
    dict_value['name'] = name
    dict_value['mobile'] = mobile
    dict_value['gender'] = 1 if gender == '男' else 0
    dict_value['graduate'] = graduate
    dict_value['department_number'] = department['department_number']
    dict_value['department_name'] = department_name
    dict_value['title'] = title
    dict_value['birthday'] = birthday
    dict_params = dict()
    dict_params['number'] = int(number) if number != '' else None
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    teacher_service.update_teacher_by_number(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def delete_teacher(request):
    number = request.GET.get('number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['number'] = number
    teacher_service.delete_teacher_by_number(dict_params)
    return result.result_response()


@api_view(['GET'])
def detail_teacher(request):
    number = request.GET.get('number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['number'] = number
    teacher_one = teacher_service.get_teacher_by_number(dict_params)
    if teacher_one is not None:
        gender = teacher_one['gender']
        if gender == 0:
            teacher_one['gender'] = "女"
        if gender == 1:
            teacher_one['gender'] = "男"
    return result.result_response(teacher_one)
