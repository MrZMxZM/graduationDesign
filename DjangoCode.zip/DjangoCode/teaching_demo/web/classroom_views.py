from rest_framework.decorators import api_view
from util import result, check_token
from service import classroom_service
from util.error_code import ErrorCode


@api_view(['GET'])
def get_classroom_list(request):
    location = request.GET.get('location')
    number = request.GET.get('number')
    seating = request.GET.get('seating')
    multimedia = request.GET.get('multimedia')
    is_enable = request.GET.get('is_enable')
    curr_page = request.GET.get('currPage')
    page_size = request.GET.get('pageSize')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['location'] = location
    dict_params['number'] = number
    dict_params['seating'] = seating
    dict_params['multimedia'] = multimedia
    dict_params['is_enable'] = is_enable
    score_dict_list = classroom_service.get_classroom_by_params(dict_params, curr_page, page_size)
    size = classroom_service.get_count_by_params(dict_params)
    size_r = int(size[0]['count(*)'])
    dict_result = dict()
    dict_result['list'] = score_dict_list
    dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['POST'])
def add_classroom(request):
    location = request.POST.get('location')
    number = request.POST.get('number')
    seating = request.POST.get('seating')
    multimedia = request.POST.get('multimedia')
    is_enable = request.POST.get('is_enable')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['location'] = location
    dict_params['number'] = number
    dict_params['seating'] = seating
    dict_params['multimedia'] = multimedia
    dict_params['is_enable'] = is_enable
    classroom_service.insert_classroom_by_params(dict_params)
    return result.result_response()


@api_view(['POST'])
def update_classroom(request):
    location = request.POST.get('location')
    number = request.POST.get('number')
    seating = request.POST.get('seating')
    multimedia = request.POST.get('multimedia')
    is_enable = request.POST.get('is_enable')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_value = dict()
    dict_value['location'] = location
    dict_value['number'] = number
    dict_value['seating'] = seating
    dict_value['multimedia'] = multimedia
    dict_value['is_enable'] = is_enable
    dict_params = dict()
    dict_params['number'] = number
    classroom_service.update_classroom_by_number(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def delete_classroom(request):
    number = request.GET.get('number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['number'] = number
    classroom_service.delete_classroom_by_number(dict_params)
    return result.result_response()


@api_view(['GET'])
def detail_classroom(request):
    number = request.GET.get('number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['number'] = number
    return result.result_response(classroom_service.get_classroom_by_number(dict_params))
