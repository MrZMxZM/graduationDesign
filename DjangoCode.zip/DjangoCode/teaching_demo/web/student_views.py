from rest_framework.decorators import api_view
from util import result, check_token
from service import student_service
from util.error_code import ErrorCode


@api_view(['GET'])
def get_student_data(request):
    number = request.GET.get('number')
    name = request.GET.get('name')
    classes = request.GET.get('classes')
    mobile = request.GET.get('mobile')
    gender = request.GET.get('gender')
    status = request.GET.get('status')
    age = request.GET.get('age')
    curr_page = request.GET.get('currPage')
    page_size = request.GET.get('pageSize')
    dict_params = dict()
    dict_params['number'] = int(number) if number != '' else None
    dict_params['name'] = name
    dict_params['classes'] = classes
    dict_params['mobile'] = mobile
    dict_params['gender'] = gender
    dict_params['status'] = status
    dict_params['age'] = age
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    student_dict_list = student_service.get_student_by_params(dict_params, curr_page, page_size)
    size = student_service.get_count_by_params(dict_params)
    # 性别,0女,1男'
    for data in student_dict_list:
        data['status_str'] = '休学' if data['status'] == 1 else '在校'
        data['gender_str'] = '男' if data['gender'] == 1 else '女'
    # conn.close()
    size_r = int(size[0]['count(*)'])
    dict_result = dict()
    dict_result['list'] = student_dict_list
    dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['POST'])
def add_student_data(request):
    number = request.POST.get('number')
    name = request.POST.get('name')
    classes = request.POST.get('classes')
    mobile = request.POST.get('mobile')
    gender = request.POST.get('gender')
    status = request.POST.get('status')
    age = request.POST.get('age')
    enrol_time = request.POST.get('enrol_time')
    citizenship = request.POST.get('citizenship')
    nation = request.POST.get('nation')
    politics_status = request.POST.get('politics_status')
    family_address = request.POST.get('family_address')
    dormitory = request.POST.get('dormitory')
    father_mobile = request.POST.get('father_mobile')
    mother_mobile = request.POST.get('mother_mobile')
    after_graduation = request.POST.get('after_graduation')
    address = request.POST.get('address')
    stu_type = request.POST.get('stu_type')
    birthday = request.POST.get('birthday')
    dict_params = dict()
    dict_params['number'] = int(number) if number != '' else None
    dict_params['name'] = name
    dict_params['classes'] = classes
    dict_params['mobile'] = mobile
    dict_params['address'] = address
    dict_params['birthday'] = birthday
    dict_params['gender'] = gender
    dict_params['status'] = status
    dict_params['age'] = age
    dict_params['enrol_time'] = enrol_time
    dict_params['citizenship'] = citizenship
    dict_params['nation'] = nation
    dict_params['politics_status'] = politics_status
    dict_params['family_address'] = family_address
    dict_params['dormitory'] = dormitory
    dict_params['father_mobile'] = father_mobile
    dict_params['mother_mobile'] = mother_mobile
    dict_params['after_graduation'] = after_graduation
    dict_params['stu_type'] = stu_type
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    student_service.insert_student_by_params(dict_params)
    return result.result_response()


@api_view(['POST'])
def update_student_data(request):
    number = request.POST.get('number')
    classes = request.POST.get('classes')
    mobile = request.POST.get('mobile')
    gender = request.POST.get('gender')
    status = request.POST.get('status')
    age = request.POST.get('age')
    enrol_time = request.POST.get('enrol_time')
    citizenship = request.POST.get('citizenship')
    nation = request.POST.get('nation')
    politics_status = request.POST.get('politics_status')
    family_address = request.POST.get('family_address')
    dormitory = request.POST.get('dormitory')
    father_mobile = request.POST.get('father_mobile')
    mother_mobile = request.POST.get('mother_mobile')
    after_graduation = request.POST.get('after_graduation')
    address = request.POST.get('address')
    stu_type = request.POST.get('stu_type')
    birthday = request.POST.get('birthday')
    dict_value = dict()
    dict_value['classes'] = classes
    dict_value['mobile'] = mobile
    dict_value['address'] = address
    dict_value['birthday'] = birthday
    dict_value['gender'] = gender
    dict_value['status'] = status
    dict_value['age'] = age
    dict_value['enrol_time'] = enrol_time
    dict_value['citizenship'] = citizenship
    dict_value['nation'] = nation
    dict_value['politics_status'] = politics_status
    dict_value['family_address'] = family_address
    dict_value['dormitory'] = dormitory
    dict_value['father_mobile'] = father_mobile
    dict_value['mother_mobile'] = mother_mobile
    dict_value['after_graduation'] = after_graduation
    dict_value['stu_type'] = stu_type
    dict_params = dict()
    dict_params['number'] = int(number) if number != '' else None

    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    student_service.update_student_by_params(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def get_student_by_number(request):
    number = request.GET.get('number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['number'] = int(number) if number != '' else None
    student_dict_list = student_service.get_student_by_number(dict_params)
    return result.result_response(student_dict_list)


@api_view(['GET'])
def delete_student_by_number(request):
    number = request.GET.get('number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['number'] = number if number != '' else None
    student_dict_list = student_service.delete_student_by_number(dict_params)
    return result.result_response(student_dict_list)
