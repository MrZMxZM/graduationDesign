from rest_framework.decorators import api_view
from util import result, check_token
from service import department_service
from util.error_code import ErrorCode


@api_view(['GET'])
def get_department_list(request):
    department_number = request.GET.get('department_number')
    department_name = request.GET.get('department_name')
    curr_page = request.GET.get('currPage')
    page_size = request.GET.get('pageSize')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['department_number'] = department_number
    dict_params['department_name'] = department_name
    score_dict_list = department_service.get_department_by_params(dict_params, curr_page, page_size)
    size = department_service.get_count_by_params(dict_params)
    size_r = int(size[0]['count(*)'])
    dict_result = dict()
    dict_result['list'] = score_dict_list
    dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['POST'])
def add_department_list(request):
    department_number = request.POST.get('department_number')
    department_name = request.POST.get('department_name')
    dict_params = dict()
    dict_params['department_name'] = department_name
    dict_params['department_number'] = department_number
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    department_service.insert_department_by_params(dict_params)
    return result.result_response()


@api_view(['POST'])
def update_department(request):
    department_name = request.POST.get('department_name')
    department_number = request.POST.get('department_number')
    dict_value = dict()
    dict_value['department_name'] = department_name
    dict_params = dict()
    dict_params['department_number'] = department_number
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    department_service.update_department_by_number(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def delete_department(request):
    department_number = request.GET.get('department_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['department_number'] = department_number
    department_service.delete_department_by_number(dict_params)
    return result.result_response()


@api_view(['GET'])
def all_department(request):
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    return result.result_response(department_service.get_department_all())

@api_view(['GET'])
def detail_department(request):
    department_number = request.GET.get('department_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['department_number'] = department_number
    department_one = department_service.get_department_by_number(dict_params)
    return result.result_response(department_one)
