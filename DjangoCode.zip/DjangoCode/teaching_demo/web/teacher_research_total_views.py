from rest_framework.decorators import api_view
from util import result, check_token
from service import teacher_research_total_service,teacher_service,research_project_service,research_paper_service,\
    perfect_course_service,competition_service
from util.error_code import ErrorCode


@api_view(['GET'])
def get_teacher_research_total_list(request):
    teacher=teacher_service.get_teacher_all()
    for i in range(len(teacher)):
        name=teacher[i].get('name')
        name_dict=dict()
        name_dict['name']=name
        teacher_research_total_service.delete_teacher_research_total_by_number(name_dict)
        number=teacher[i].get('number')
        gender=teacher[i].get('gender')
        leader_dict=dict()
        leader_dict['leader']=name
        first_author_dict=dict()
        first_author_dict['first_author']=name
        tutor_dict=dict()
        tutor_dict['tutor']=name
        research_project=research_project_service.get_research_project_by_params(leader_dict, curr_page='', page_size='')
        perfect_course=perfect_course_service.get_perfect_course_by_params(leader_dict, curr_page='', page_size='')
        research_paper=research_paper_service.get_research_paper_by_params(first_author_dict, curr_page='', page_size='')
        competition=competition_service.get_competition_by_params(tutor_dict, curr_page='', page_size='')
        params_dict=dict()
        params_dict['research_project']=len(research_project)
        params_dict['perfect_course']=len(perfect_course)
        params_dict['research_paper']=len(research_paper)
        params_dict['competition']=len(competition)
        params_dict['number']=number
        params_dict['name']=name
        params_dict['gender']=gender
        teacher_research_total_service.insert_teacher_research_total_by_params(params_dict)
    number = request.GET.get('number')
    name = request.GET.get('name')
    curr_page = request.GET.get('currPage')
    page_size = request.GET.get('pageSize')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['number'] = number
    dict_params['name'] = name
    score_dict_list = teacher_research_total_service.get_teacher_research_total_by_params(dict_params, curr_page, page_size)
    size = teacher_research_total_service.get_count_by_params(dict_params)
    size_r = int(size[0]['count(*)'])
    dict_result = dict()
    dict_result['list'] = score_dict_list
    dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['POST'])
def add_teacher_research_total(request):
    number = request.POST.get('number')
    name = request.POST.get('name')
    gender = request.POST.get('gender')
    research_project = request.POST.get('research_project')
    research_paper = request.POST.get('research_paper')
    perfect_course = request.POST.get('perfect_course')
    competition = request.POST.get('competition')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['number'] = number
    dict_params['name'] = name
    dict_params['gender'] = gender
    dict_params['research_project'] = research_project
    dict_params['perfect_course'] = perfect_course
    dict_params['competition'] = competition
    teacher_research_total_service.insert_teacher_research_total_by_params(dict_params)
    return result.result_response()


@api_view(['POST'])
def update_teacher_research_total(request):
    number = request.POST.get('number')
    name = request.POST.get('name')
    gender = request.POST.get('gender')
    research_project = request.POST.get('research_project')
    research_paper = request.POST.get('research_paper')
    perfect_course = request.POST.get('perfect_course')
    competition = request.POST.get('competition')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_value = dict()
    dict_value['number'] = number
    dict_value['name'] = name
    dict_value['gender'] = gender
    dict_value['research_project'] = research_project
    dict_value['research_paper'] = research_paper
    dict_value['perfect_course'] = perfect_course
    dict_value['competition'] = competition
    dict_params = dict()
    dict_params['number'] = number
    teacher_research_total_service.update_teacher_research_total_by_number(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def delete_teacher_research_total(request):
    number = request.GET.get('number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['number'] = number
    teacher_research_total_service.delete_teacher_research_total_by_number(dict_params)
    return result.result_response()


@api_view(['GET'])
def detail_teacher_research_total(request):
    number = request.GET.get('number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['number'] = number
    return result.result_response(teacher_research_total_service.get_teacher_research_total_by_number(dict_params))
