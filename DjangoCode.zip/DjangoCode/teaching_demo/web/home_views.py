from rest_framework.decorators import api_view
from util import result, encryption, redis_pool
from service import home_service
from util.error_code import ErrorCode
import random
import string

config= ['save', 'show','delete','change','assign','role','teacher','score_save']

@api_view(['POST'])
def login(request):
    pwd = request.POST.get('pwd')
    account = request.POST.get('account')
    str_type = request.POST.get('type')
    dict_params = dict()
    dict_params['account'] = account
    dict_params['type'] = int(str_type)
    supervisor_dict_list = home_service.get_supervisor_by_params(dict_params)
    if supervisor_dict_list is None:
        return result.response_error(ErrorCode.LOGIN_ACCOUNT_FAIL)
    en_pwd = encryption.md5_encrypt(pwd)
    print(en_pwd)
    if len(supervisor_dict_list) != 0:
        if en_pwd == str(supervisor_dict_list[0]['password']):
            token = str(account) + "_" + str(str_type)
            redis_pool.set(token, ''.join(random.sample(string.ascii_letters + string.digits, 8)), 1200)
            dict_token = dict()
            dict_token['token'] = bytes.decode(encryption.base64_encode(bytes(token, 'UTF-8')), 'utf8')
            dict_params_role = dict()
            dict_params_role['type'] = int(str_type)
            dict_list = home_service.get_role_by_params(dict_params_role)
            config_list=str(dict_list[0]['role_data']).split(',')
            list_config=list()
            for i in range(len(config_list)):
                list_config.append(config[int(config_list[i])])
            dict_token['right'] = ','.join(list_config)
            return result.result_response(dict_token)
        else:
            return result.response_error(ErrorCode.LOGIN_PWD_FAIL)
