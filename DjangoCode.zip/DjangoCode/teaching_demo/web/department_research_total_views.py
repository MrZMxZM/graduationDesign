from rest_framework.decorators import api_view
from util import result, check_token
from service import department_research_total_service,teacher_research_total_service,research_paper_service,\
    research_project_service,teacher_service,perfect_course_service,competition_service,department_service
from util.error_code import ErrorCode


@api_view(['GET'])
def get_department_research_total_list(request):
    teacher = teacher_service.get_teacher_all()
    department = department_service.get_department_all()
    for j in range(len(department)):
        research_project = 0
        perfect_course = 0
        research_paper = 0
        competition = 0
        department_name=department[j].get("department_name")
        department_number=department[j].get("department_number")
        department_number_dict=dict()
        department_number_dict['department_number']=department_number
        department_research_total_service.delete_department_research_total_by_number(department_number_dict)
        for i in range(len(teacher)):
            if department_name==teacher[i].get('department_name'):
                name = teacher[i].get('name')
                leader_dict = dict()
                leader_dict['leader'] = name
                first_author_dict = dict()
                first_author_dict['first_author'] = name
                tutor_dict = dict()
                tutor_dict['tutor'] = name
                research_project_list = research_project_service.get_research_project_by_params(leader_dict, curr_page='',
                                                                                           page_size='')
                perfect_course_list = perfect_course_service.get_perfect_course_by_params(leader_dict, curr_page='', page_size='')
                research_paper_list = research_paper_service.get_research_paper_by_params(first_author_dict, curr_page='',
                                                                                     page_size='')
                competition_list = competition_service.get_competition_by_params(tutor_dict, curr_page='', page_size='')
                research_project+=len(research_project_list)
                perfect_course+=len(perfect_course_list)
                research_paper+=len(research_paper_list)
                competition+=len(competition_list)
        params_dict = dict()
        params_dict['research_project'] = research_project
        params_dict['perfect_course'] = perfect_course
        params_dict['research_paper'] = research_paper
        params_dict['competition'] = competition
        params_dict['department_name'] = department_name
        params_dict['department_number'] = department_number
        department_research_total_service.insert_department_research_total_by_params(params_dict)
    department_number = request.GET.get('department_number')
    department_name = request.GET.get('department_name')
    curr_page = request.GET.get('currPage')
    page_size = request.GET.get('pageSize')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['department_number'] = department_number
    dict_params['department_name'] = department_name
    score_dict_list = department_research_total_service.get_department_research_total_by_params(dict_params, curr_page, page_size)
    size = department_research_total_service.get_count_by_params(dict_params)
    size_r = int(size[0]['count(*)'])
    dict_result = dict()
    dict_result['list'] = score_dict_list
    dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['POST'])
def add_department_research_total(request):
    department_number = request.POST.get('department_number')
    department_name = request.POST.get('department_name')
    research_project = request.POST.get('research_project')
    research_paper = request.POST.get('research_paper')
    perfect_course = request.POST.get('perfect_course')
    competition = request.POST.get('competition')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['department_number'] = department_number
    dict_params['department_name'] = department_name
    dict_params['research_project'] = research_project
    dict_params['research_paper'] = research_paper
    dict_params['perfect_course'] = perfect_course
    dict_params['competition'] = competition
    department_research_total_service.insert_department_research_total_by_params(dict_params)
    return result.result_response()


@api_view(['POST'])
def update_department_research_total(request):
    department_number = request.POST.get('department_number')
    department_name = request.POST.get('department_name')
    research_project = request.POST.get('research_project')
    research_paper = request.POST.get('research_paper')
    perfect_course = request.POST.get('perfect_course')
    competition = request.POST.get('competition')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_value = dict()
    dict_value['department_name'] = department_name
    dict_value['research_project'] = research_project
    dict_value['research_paper'] = research_paper
    dict_value['competition'] = competition
    dict_value['perfect_course'] = perfect_course
    dict_params = dict()
    dict_params['paper_number'] = department_number
    department_research_total_service.update_department_research_total_by_number(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def delete_department_research_total(request):
    department_number = request.GET.get('department_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['department_number'] = department_number
    department_research_total_service.delete_department_research_total_by_number(dict_params)
    return result.result_response()


@api_view(['GET'])
def detail_department_research_total(request):
    department_number = request.GET.get('department_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['department_number'] = department_number
    return result.result_response(department_research_total_service.get_department_research_total_by_number(dict_params))
