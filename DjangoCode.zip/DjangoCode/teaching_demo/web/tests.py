from django.test import TestCase
from rest_framework.decorators import api_view
from util import result


# Create your tests here.
@api_view(['GET'])
def hello_world():
    d = dict()
    d['test'] = "hello world"
    return result.result_response(d)
