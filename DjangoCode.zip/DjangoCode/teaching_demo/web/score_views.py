from rest_framework.decorators import api_view
from util import result, check_token
from service import score_service, student_service
from util.error_code import ErrorCode


@api_view(['GET'])
def get_score_data(request):
    stu_number = request.GET.get('stu_number')
    stu_name = request.GET.get('stu_name')
    stu_classes = request.GET.get('stu_classes')
    cou_name = request.GET.get('cou_name')
    # curr_page = request.GET.get('currPage')
    # page_size = request.GET.get('pageSize')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['stu_number'] = stu_number
    dict_params['stu_name'] = stu_name
    dict_params['stu_classes'] = stu_classes
    dict_params['cou_name'] = cou_name
    score_dict_list = score_service.get_score_by_params(dict_params)
    # size = score_service.get_count_by_params(conn, dict_params)
    # size_r = int(size[0]['count(*)'])
    dict_obj = dict()
    list_obj = list()

    for score_dict in score_dict_list:
        score_dict_obj = dict()
        score_dict_obj['stu_number'] = score_dict['stu_number']
        score_dict_obj['stu_name'] = score_dict['stu_name']
        score_dict_obj['stu_classes'] = score_dict['stu_classes']
        score_dict_obj['test_name'] = score_dict['test_name']
        dict_obj[score_dict['stu_number'] + '_' + score_dict['test_name']] = score_dict_obj
    for k, v in dict_obj.items():
        list_obj.append(v)
    dict_result = dict()

    dict_result['list'] = list_obj
    # dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['GET'])
def get_score_data_detail(request):
    stu_number = request.GET.get('stu_number')
    test_name = request.GET.get('test_name')
    dict_params = dict()
    dict_params['stu_number'] = stu_number
    dict_params['test_name'] = test_name
    score_dict_list = score_service.get_score_by_stu_number(dict_params)
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_result = dict()
    dict_result['stu_name'] = score_dict_list[0]['stu_name']
    dict_result['stu_classes'] = score_dict_list[0]['stu_classes']
    dict_result['stu_number'] = score_dict_list[0]['stu_number']
    cou_name_gender = list()
    total = 0
    j = 0
    for i in range(len(score_dict_list)):
        grade = score_dict_list[i]['grade']
        dict_cou_name_gender = dict()
        dict_cou_name_gender['cou_name'] = score_dict_list[i]['cou_name'] + '(' + \
                                           score_dict_list[i]['cou_number'] + ')'
        if grade is not None:
            total += grade
        j += 1
        dict_cou_name_gender['grade'] = grade
        cou_name_gender.append(dict_cou_name_gender)
    dict_result['cou_name_gender'] = cou_name_gender
    dict_result['total'] = total
    if total != 0:
        dict_result['average_score'] = total / j
    return result.result_response(dict_result)


@api_view(['GET'])
def add_score_data(request):
    stu_number = request.GET.get('stu_number')
    test_name = request.GET.get('test_name')
    dict_params = dict()
    dict_params['stu_number'] = stu_number
    dict_params['test_name'] = test_name
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)


@api_view(['GET'])
def get_course_all(request):
    """
    弃用
    :param request:
    :return:
    """
    stu_number = request.GET.get('stu_number')
    dict_params = dict()
    dict_params['stu_number'] = stu_number
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    score_dict_all = score_service.get_course_all()
    return result.result_response(score_dict_all)


@api_view(['POST'])
def update_score_data(request):
    stu_number = request.POST.get('stu_number')
    test_name = request.POST.get('test_name')
    dict_params = dict()
    dict_params['stu_number'] = stu_number
    dict_params['test_name'] = test_name
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    score_dict_list = score_service.get_score_by_stu_number(dict_params)
    for i in range(len(score_dict_list)):
        dict_value = dict()
        dict_params = dict()
        dict_params['id'] = score_dict_list[i]['id']
        courseArrValue = 'courseArrValue' + '[' + str(i) + ']'
        dict_value['grade'] = request.POST.get(courseArrValue)
        score_service.update_score_by_stu_number(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def delete_score_data(request):
    stu_number = request.GET.get('stu_number')
    test_name = request.GET.get('test_name')
    dict_params = dict()
    dict_params['stu_number'] = stu_number
    dict_params['test_name'] = test_name
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    score_service.delete_score(dict_params)
    return result.result_response()
