from rest_framework.decorators import api_view
from util import result, check_token
from service import research_project_service
from util.error_code import ErrorCode


@api_view(['GET'])
def get_research_project_list(request):
    subject_number = request.GET.get('subject_number')
    subject_name = request.GET.get('subject_name')
    level = request.GET.get('level')
    leader = request.GET.get('leader')
    status = request.GET.get('status')
    curr_page = request.GET.get('currPage')
    page_size = request.GET.get('pageSize')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['subject_number'] = subject_number
    dict_params['subject_name'] = subject_name
    dict_params['level'] = level
    dict_params['leader'] = leader
    dict_params['status'] = status
    score_dict_list = research_project_service.get_research_project_by_params(dict_params, curr_page, page_size)
    size = research_project_service.get_count_by_params(dict_params)
    size_r = int(size[0]['count(*)'])
    dict_result = dict()
    dict_result['list'] = score_dict_list
    dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['POST'])
def add_research_project_list(request):
    subject_number = request.POST.get('subject_number')
    subject_name = request.POST.get('subject_name')
    level = request.POST.get('level')
    complete_unit = request.POST.get('complete_unit')
    leader = request.POST.get('leader')
    members = request.POST.get('members')
    funding = request.POST.get('funding')
    start_time = request.POST.get('start_time')
    end_time = request.POST.get('end_time')
    status = request.POST.get('status')
    dict_params = dict()
    dict_params['subject_number'] = subject_number
    dict_params['complete_unit'] = complete_unit
    dict_params['members'] = members
    dict_params['funding'] = funding
    dict_params['start_time'] = start_time
    dict_params['end_time'] = end_time
    dict_params['leader'] = leader
    dict_params['level'] = level
    dict_params['subject_name'] = subject_name
    dict_params['status'] = status
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    research_project_service.insert_research_project_by_params(dict_params)
    return result.result_response()


@api_view(['POST'])
def update_research_project(request):
    subject_number = request.POST.get('subject_number')
    subject_name = request.POST.get('subject_name')
    level = request.POST.get('level')
    complete_unit = request.POST.get('complete_unit')
    leader = request.POST.get('leader')
    members = request.POST.get('members')
    funding = request.POST.get('funding')
    start_time = request.POST.get('start_time')
    end_time = request.POST.get('end_time')
    status = request.POST.get('status')
    dict_value = dict()
    dict_value['subject_number'] = subject_number
    dict_value['complete_unit'] = complete_unit
    dict_value['members'] = members
    dict_value['funding'] = funding
    dict_value['start_time'] = start_time
    dict_value['end_time'] = end_time
    dict_value['leader'] = leader
    dict_value['level'] = level
    dict_value['subject_name'] = subject_name
    dict_value['status'] = status
    dict_params = dict()
    dict_params['subject_number'] = subject_number
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    research_project_service.update_research_project_by_number(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def delete_research_project(request):
    subject_number = request.GET.get('subject_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['subject_number'] = subject_number
    research_project_service.delete_research_project_by_number(dict_params)
    return result.result_response()


@api_view(['GET'])
def detail_research_project(request):
    subject_number = request.GET.get('subject_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['subject_number'] = subject_number
    return result.result_response(research_project_service.get_research_project_by_number(dict_params))

