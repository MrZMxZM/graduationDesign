from rest_framework.decorators import api_view
from util import result, check_token
from service import research_paper_service
from util.error_code import ErrorCode


@api_view(['GET'])
def get_research_paper_list(request):
    paper_title = request.GET.get('paper_title')
    first_author = request.GET.get('first_author')
    status = request.GET.get('status')
    curr_page = request.GET.get('currPage')
    page_size = request.GET.get('pageSize')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['paper_title'] = paper_title
    dict_params['first_author'] = first_author
    dict_params['status'] = status
    score_dict_list = research_paper_service.get_research_paper_by_params(dict_params, curr_page, page_size)
    size = research_paper_service.get_count_by_params(dict_params)
    size_r = int(size[0]['count(*)'])
    dict_result = dict()
    dict_result['list'] = score_dict_list
    dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['POST'])
def add_research_paper(request):
    paper_title = request.POST.get('paper_title')
    first_author = request.POST.get('first_author')
    status = request.POST.get('status')
    publications = request.POST.get('publications')
    level = request.POST.get('level')
    retrieve = request.POST.get('retrieve')
    other_authors = request.POST.get('other_authors')
    published_time = request.POST.get('published_time')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['paper_title'] = paper_title
    dict_params['first_author'] = first_author
    dict_params['status'] = status
    dict_params['publications'] = publications
    dict_params['level'] = level
    dict_params['retrieve'] = retrieve
    dict_params['other_authors'] = other_authors
    dict_params['published_time'] = published_time
    research_paper_service.insert_research_paper_by_params(dict_params)
    return result.result_response()


@api_view(['POST'])
def update_research_paper(request):
    paper_title = request.POST.get('paper_title')
    first_author = request.POST.get('first_author')
    status = request.POST.get('status')
    publications = request.POST.get('publications')
    level = request.POST.get('level')
    retrieve = request.POST.get('retrieve')
    other_authors = request.POST.get('other_authors')
    published_time = request.POST.get('published_time')
    paper_number = request.POST.get('paper_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_value = dict()
    dict_value['paper_title'] = paper_title
    dict_value['first_author'] = first_author
    dict_value['status'] = status
    dict_value['publications'] = publications
    dict_value['level'] = level
    dict_value['retrieve'] = retrieve
    dict_value['published_time'] = published_time
    dict_value['other_authors'] = other_authors
    dict_params = dict()
    dict_params['paper_number'] = paper_number
    research_paper_service.update_research_paper_by_number(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def delete_research_paper(request):
    paper_number = request.GET.get('paper_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['paper_number'] = paper_number
    research_paper_service.delete_research_paper_by_number(dict_params)
    return result.result_response()


@api_view(['GET'])
def detail_research_paper(request):
    paper_number = request.GET.get('paper_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['paper_number'] = paper_number
    return result.result_response(research_paper_service.get_research_paper_by_number(dict_params))
