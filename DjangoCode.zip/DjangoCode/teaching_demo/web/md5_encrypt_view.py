from rest_framework.decorators import api_view
from util import result, encryption,check_token
from util.error_code import ErrorCode
from service import home_service

@api_view(['GET'])
def get_pwd(request):
    r = encryption.md5_encrypt(request.GET.get('pwd'))
    return result.result_response(r)


@api_view(['POST'])
def update_pwd(request):
    newPassword = request.POST.get('newPassword')
    oldPassword = request.POST.get('oldPassword')
    confirmPassword = request.POST.get('confirmPassword')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    de_token = bytes.decode(encryption.base64_decode(bytes(token, 'UTF-8')))
    token_arr = str(de_token).split("_")
    account = token_arr[0]
    str_type = token_arr[1]
    dict_params = dict()
    dict_params['account'] = account
    dict_params['type'] = int(str_type)
    supervisor_dict_list = home_service.get_supervisor_by_params(dict_params)

    if newPassword != confirmPassword:
        return result.response_error(ErrorCode.PASSWORD_MISMATCH)
    if encryption.md5_encrypt(oldPassword) != supervisor_dict_list[0]['password']:
        return result.response_error(ErrorCode.LOGIN_PWD_FAIL)
    newPasswordStr = encryption.md5_encrypt(newPassword)
    dict_value=dict()
    dict_value['password']=newPasswordStr
    home_service.update_by_number(dict_value, dict_params)
    return result.result_response()


@api_view(['POST'])
def add_account(request):
    password = request.POST.get('password')
    account = request.POST.get('account')
    is_enable = request.POST.get('is_enable')
    desc_role = request.POST.get('desc_role')
    type = request.POST.get('type')
    dict_params = dict()
    dict_params['account'] = account
    dict_params['type'] = type
    dict_params['password'] = encryption.md5_encrypt(password)
    dict_params1 = dict()
    dict_params1['account'] = str(account)
    dict_params1['is_enable'] = int(is_enable)
    dict_params1['desc_role'] = desc_role

    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    home_service.insert_by_params(dict_params)
    home_service.insert_right_by_params(dict_params1)
    return result.result_response()


@api_view(['GET'])
def show_account(request):
    account = request.GET.get('account')
    curr_page = request.GET.get('currPage')
    page_size = request.GET.get('pageSize')
    dict_params = dict()
    dict_params['account'] = account
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    score_dict_list = home_service.get_right_by_params(dict_params, curr_page, page_size)
    size = home_service.get_count_by_params(dict_params)
    size_r = int(size[0]['count(*)'])
    dict_result = dict()
    dict_result['list'] = score_dict_list
    dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['POST'])
def update_right(request):
    account = request.POST.get('account')
    is_enable = request.POST.get('is_enable')
    desc_role = request.POST.get('desc_role')
    dict_params = dict()
    dict_params['account'] = account
    dict_value = dict()
    dict_value['account'] = account
    dict_value['is_enable'] = int(is_enable)
    dict_value['desc_role'] = desc_role

    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    home_service.update_right_by_cou_number(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def detail_right(request):
    account = request.GET.get('account')
    dict_params = dict()
    dict_params['account'] = account
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    return result.result_response(home_service.get_right_by_number(dict_params))


@api_view(['GET'])
def delete_right(request):
    account = request.GET.get('account')
    dict_params = dict()
    dict_params['account'] = account
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    return result.result_response(home_service.delete_right_by_number(dict_params))