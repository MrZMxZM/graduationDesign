from rest_framework.decorators import api_view
from util import result, check_token
from service import course_service, score_service, student_service
from util.error_code import ErrorCode


@api_view(['GET'])
def get_course_list(request):
    name = request.GET.get('name')
    number = request.GET.get('number')
    type = request.GET.get('type')
    is_learn = request.GET.get('is_learn')
    curr_page = request.GET.get('currPage')
    page_size = request.GET.get('pageSize')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['name'] = name
    dict_params['number'] = number
    dict_params['type'] = type
    dict_params['is_learn'] = is_learn
    score_dict_list = course_service.get_course_by_params(dict_params, curr_page, page_size)
    size = course_service.get_count_by_params(dict_params)
    size_r = int(size[0]['count(*)'])
    dict_result = dict()
    dict_result['list'] = score_dict_list
    dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['POST'])
def add_course_list(request):
    number = request.POST.get('number')
    name = request.POST.get('name')
    type = request.POST.get('type')
    is_enable = request.POST.get('is_enable')
    term = request.POST.get('term')
    course_hour = request.POST.get('course_hour')
    course_score = request.POST.get('course_score')
    is_learn = request.POST.get('is_learn')
    dict_params = dict()
    dict_params['number'] = number
    dict_params['name'] = name
    dict_params['type'] = type
    dict_params['is_enable'] = int(is_enable)
    dict_params['term'] = term
    dict_params['course_hour'] = course_hour
    dict_params['course_score'] = course_score
    dict_params['is_learn'] = int(is_learn)
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    course_service.insert_course_by_params(dict_params)
    return result.result_response()


@api_view(['GET'])
def assign_course(request):
    test_name = request.GET.get('test_name')
    classes = request.GET.get('classes')
    courses = request.GET.getlist('courses[]')
    coursesName = request.GET.getlist('coursesName[]')
    dict_classes = dict()
    dict_classes['classes'] = classes
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    student_list = student_service.get_student_by_params(dict_classes, curr_page='', page_size='')
    for i in range(len(student_list)):
        dict_params = dict()
        dict_params['stu_number'] = student_list[i]['number']
        dict_params['stu_name'] = student_list[i]['name']
        dict_params['stu_classes'] = classes
        dict_params['test_name'] = test_name
        for j in range(len(courses)):
            dict_params['cou_number'] = courses[j]
            dict_params['cou_name'] = coursesName[j]
            score_service.insert_score(dict_params)
    return result.result_response()


@api_view(['POST'])
def update_course(request):
    name = request.POST.get('name')
    type = request.POST.get('type')
    is_enable = request.POST.get('is_enable')
    term = request.POST.get('term')
    course_hour = request.POST.get('course_hour')
    course_score = request.POST.get('course_score')
    is_learn = request.POST.get('is_learn')
    number = request.POST.get('number')
    dict_value = dict()
    dict_value['name'] = name
    dict_value['type'] = type
    dict_value['is_enable'] = is_enable
    dict_value['term'] = term
    dict_value['course_hour'] = course_hour
    dict_value['course_score'] = course_score
    dict_value['is_learn'] = is_learn
    dict_params = dict()
    dict_params['number'] = number
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    course_service.update_course_by_cou_number(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def detail_course(request):
    number = request.GET.get('number')
    dict_params = dict()
    dict_params['number'] = number
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    return result.result_response(course_service.get_course_by_number(dict_params))


@api_view(['GET'])
def delete_course(request):
    number = request.GET.get('number')
    dict_params = dict()
    dict_params['number'] = number
    token = request.headers.get('token')
    if check_token.check(token) is None:
        result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    return result.result_response(course_service.delete_course_by_number(dict_params))