from rest_framework.decorators import api_view
from util import result, check_token
from service import competition_service
from util.error_code import ErrorCode


@api_view(['GET'])
def get_competition_list(request):
    race_name = request.GET.get('race_name')
    level = request.GET.get('level')
    tutor = request.GET.get('tutor')
    status = request.GET.get('status')
    student_name = request.GET.get('student_name')
    curr_page = request.GET.get('currPage')
    page_size = request.GET.get('pageSize')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['race_name'] = race_name
    dict_params['level'] = level
    dict_params['tutor'] = tutor
    dict_params['student_name'] = student_name
    dict_params['status'] = status
    score_dict_list = competition_service.get_competition_by_params(dict_params, curr_page, page_size)
    size = competition_service.get_count_by_params(dict_params)
    size_r = int(size[0]['count(*)'])
    dict_result = dict()
    dict_result['list'] = score_dict_list
    dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['POST'])
def add_competition(request):
    race_name = request.POST.get('race_name')
    winning_time = request.POST.get('winning_time')
    level = request.POST.get('level')
    reward_level = request.POST.get('reward_level')
    tutor = request.POST.get('tutor')
    student_name = request.POST.get('student_name')
    status = request.POST.get('status')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['race_name'] = race_name
    dict_params['winning_time'] = winning_time
    dict_params['level'] = level
    dict_params['tutor'] = tutor
    dict_params['reward_level'] = reward_level
    dict_params['student_name'] = student_name
    dict_params['status'] = status
    competition_service.insert_competition_by_params(dict_params)
    return result.result_response()


@api_view(['POST'])
def update_competition(request):
    race_name = request.POST.get('race_name')
    winning_time = request.POST.get('winning_time')
    level = request.POST.get('level')
    reward_level = request.POST.get('reward_level')
    tutor = request.POST.get('tutor')
    student_name = request.POST.get('student_name')
    status = request.POST.get('status')
    competition_number = request.POST.get('competition_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_value = dict()
    dict_value['race_name'] = race_name
    dict_value['winning_time'] = winning_time
    dict_value['reward_level'] = reward_level
    dict_value['level'] = level
    dict_value['tutor'] = tutor
    dict_value['student_name'] = student_name
    dict_value['status'] = status
    dict_params = dict()
    dict_params['competition_number'] = competition_number
    competition_service.update_competition_by_number(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def delete_competition(request):
    competition_number = request.GET.get('competition_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['competition_number'] = competition_number
    competition_service.delete_competition_by_number(dict_params)
    return result.result_response()


@api_view(['GET'])
def detail_competition(request):
    competition_number = request.GET.get('competition_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['competition_number'] = competition_number
    return result.result_response(competition_service.get_competition_by_number(dict_params))
