from rest_framework.decorators import api_view
from util import result, check_token
from service import perfect_course_service
from util.error_code import ErrorCode


@api_view(['GET'])
def get_perfect_course_list(request):
    class_name = request.GET.get('class_name')
    level = request.GET.get('level')
    leader = request.GET.get('leader')
    status = request.GET.get('status')
    curr_page = request.GET.get('currPage')
    page_size = request.GET.get('pageSize')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['class_name'] = class_name
    dict_params['level'] = level
    dict_params['leader'] = leader
    dict_params['status'] = status
    score_dict_list = perfect_course_service.get_perfect_course_by_params(dict_params, curr_page, page_size)
    size = perfect_course_service.get_count_by_params(dict_params)
    size_r = int(size[0]['count(*)'])
    dict_result = dict()
    dict_result['list'] = score_dict_list
    dict_result['size'] = size_r
    return result.result_response(dict_result)


@api_view(['POST'])
def add_perfect_course(request):
    class_name = request.POST.get('class_name')
    level = request.POST.get('level')
    leader = request.POST.get('leader')
    members = request.POST.get('members')
    approval_time = request.POST.get('approval_time')
    evaluate_unit = request.POST.get('evaluate_unit')
    status = request.POST.get('status')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['class_name'] = class_name
    dict_params['level'] = level
    dict_params['leader'] = leader
    dict_params['members'] = members
    dict_params['level'] = level
    dict_params['approval_time'] = approval_time
    dict_params['evaluate_unit'] = evaluate_unit
    dict_params['status'] = status
    perfect_course_service.insert_perfect_course_by_params(dict_params)
    return result.result_response()


@api_view(['POST'])
def update_perfect_course(request):
    class_name = request.POST.get('class_name')
    level = request.POST.get('level')
    leader = request.POST.get('leader')
    members = request.POST.get('members')
    approval_time = request.POST.get('approval_time')
    evaluate_unit = request.POST.get('evaluate_unit')
    status = request.POST.get('status')
    perfect_course_number = request.POST.get('perfect_course_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_value = dict()
    dict_value['class_name'] = class_name
    dict_value['leader'] = leader
    dict_value['status'] = status
    dict_value['members'] = members
    dict_value['level'] = level
    dict_value['approval_time'] = approval_time
    dict_value['evaluate_unit'] = evaluate_unit
    dict_params = dict()
    dict_params['perfect_course_number'] = perfect_course_number
    perfect_course_service.update_perfect_course_by_number(dict_value, dict_params)
    return result.result_response()


@api_view(['GET'])
def delete_perfect_course(request):
    perfect_course_number = request.GET.get('perfect_course_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['perfect_course_number'] = perfect_course_number
    perfect_course_service.delete_perfect_course_by_number(dict_params)
    return result.result_response()


@api_view(['GET'])
def detail_perfect_course(request):
    perfect_course_number = request.GET.get('perfect_course_number')
    token = request.headers.get('token')
    if check_token.check(token) is None:
        return result.response_error(ErrorCode.TOKEN_NOT_AVAILABLE)
    dict_params = dict()
    dict_params['perfect_course_number'] = perfect_course_number
    return result.result_response(perfect_course_service.get_perfect_course_by_number(dict_params))
