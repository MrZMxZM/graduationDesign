import Vue from "vue";
import Router from "vue-router";
import Home from "./views/Home.vue";

Vue.use(Router);

let router =  new Router({
  routes: [
    {
      path: "/login",
      name: "login",
      component: () => import("./views/Login.vue"),
      meta: {
        title: "登录"
      }
    },
    {
      path: "/",
      name: "home",
      component: Home,
      meta: {
        title: "首页",
        redirect: {
          info: "info",
          department: "department",
          student: "student",
          search: "search",
          system: "system",
        }
      },
      redirect: to => {
        if (!localStorage.getItem("token")) {
          return { name: "login" };
        }
        for (let [power, routerName] of Object.entries(to.meta.redirect)) {
          if (localStorage.getItem("token")) {
            return { name: routerName };
          }
        }
        return "/";
      },
      children: [
        {
          path: "info",
          name: "info",
          component: () => import("./views/Info.vue"),
          meta: {
            title: "教师信息信息管理",
            redirect: {
              teacherInfoManage: "teacherInfoManage"
            }
          },
          redirect: to => {
            for (let [power, routerName] of Object.entries(to.meta.redirect)) {
              if (localStorage.getItem("token")) {
                return { name: routerName };
              }
            }
            return "/info";
          },
          children: [
            {
              path: "teacherInfoManage",
              name: "teacherInfoManage",
              component: () => import("./views/infoManage/TeacherInfoManage.vue")
            }
          ]
        },

        {
          path: "department",
          name: "department",
          component: () => import("./views/Department.vue"),
          meta: {
            title: "部门信息信息管理",
            redirect: {
              departmentInfo: "departmentInfo"
            }
          },
          redirect: to => {
            for (let [power, routerName] of Object.entries(to.meta.redirect)) {
              if (localStorage.getItem("token")) {
                return { name: routerName };
              }
            }
            return "/department";
          },
          children: [
            {
              path: "departmentInfo",
              name: "departmentInfo",
              component: () => import("./views/departmentManage/DepartmentInfo.vue")
            }
          ]
        },

        {
          path: "student",
          name: "student",
          component: () => import("./views/Student.vue"),
          meta: {
            title: "教研成果管理",
            redirect: {
              filesManage: "filesManage",
              resultsManage: "resultsManage",
              perfectCourse: "perfectCourse",
              competition: "competition",
            }
          },
          redirect: to => {
            for (let [power, routerName] of Object.entries(to.meta.redirect)) {
              if (localStorage.getItem("token")) {
                return { name: routerName };
              }
            }
            return "/student";
          },
          children: [
            {
              path: "filesManage",
              name: "filesManage",
              component: () => import("./views/studentManage/FilesManage.vue")
            },
            {
              path: "ResultsManage",
              name: "ResultsManage",
              component: () => import("./views/studentManage/ResultsManage.vue")
            },
            {
              path: "perfectCourse",
              name: "perfectCourse",
              component: () => import("./views/studentManage/PerfectCourse.vue")
            },
            {
              path: "competition",
              name: "competition",
              component: () => import("./views/studentManage/Competition.vue")
            }
          ]
        },
        {
          path: "search",
          name: "search",
          component: () => import("./views/Search.vue"),
          meta: {
            title: "统计查询管理",
            redirect: {
              studentInfo: "studentInfo",
              courseInfo: "courseInfo",
              resultsInfo: "resultsInfo",
              teachersInfo: "teachersInfo",
            }
          },
          redirect: to => {
            for (let [power, routerName] of Object.entries(to.meta.redirect)) {
              if (localStorage.getItem("token")) {
                return { name: routerName };
              }
            }
            return "/student";
          },
          children: [
            {
              path: "studentInfo",
              name: "studentInfo",
              component: () => import("./views/searchs/StudentInfo.vue")
            },
            {
              path: "courseInfo",
              name: "courseInfo",
              component: () => import("./views/searchs/CourseInfo.vue")
            },
            {
              path: "resultsInfo",
              name: "resultsInfo",
              component: () => import("./views/searchs/ResultsInfo.vue")
            },
            {
              path: "teachersInfo",
              name: "teachersInfo",
              component: () => import("./views/searchs/TeachersInfo.vue")
            }
          ]
        },
        {
          path: "system",
          name: "system",
          component: () => import("./views/System.vue"),
          meta: {
            title: "系统管理",
            redirect: {
              changePassword: "changePassword",
              permissionsManage: "permissionsManage"
            }
          },
          redirect: to => {
            for (let [power, routerName] of Object.entries(to.meta.redirect)) {
              if (localStorage.getItem("token")) {
                return { name: routerName };
              }
            }
            return "/system";
          },
          children: [
            {
              path: "changePassword",
              name: "changePassword",
              component: () => import("./views/systemManage/ChangePassword.vue")
            },
            {
              path: "permissionsManage",
              name: "permissionsManage",
              component: () => import("./views/systemManage/PermissionsManage.vue")
            }
          ]
        }
      ]
    }
  ]
});

router.beforeEach((to, from, next) => {
  const token = localStorage.getItem("token");
  if (!token && to.name !== "login") {
    next("/login");
  } else {
    next();
  }
});

export default router;
