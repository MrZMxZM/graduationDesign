import axios from "axios";
import qs from "qs";

// axios.defaults.baseURL = "10.10.10.200:5170";
axios.defaults.baseURL = "http://127.0.0.1:8000";
axios.interceptors.request.use(
  config => {
    const token = localStorage.getItem("token");
    if(token) {
      if(config && config.headers) {
        config.headers.token = token;
      }else {
        config = {
          headers: {
            token
          }
        }
      }
    }
    return config;
  },
error => {
    return Promise.reject(error);
  }
);

axios.interceptors.response.use(
  response => {
    const data = response.data;
    if (data) {
      console.log(2222,data)
      switch (data.code) {
        case "200":
          break;
      }
      if(data.code === "10000004") {
        this.$router.replace({
          path: "/login"
        })
      }
      if (data.success) {
        return data.data;
      } else {
        return Promise.reject(data.message);
      }
    } else {
      return {};
    }
  },
  error => {
    return Promise.reject("正在更新维护中");
  }
);

axios.getRequest = (url, params, responseType) => {
  return axios.get(url, { params: params, responseType: responseType });
};

axios.postRequest = (url, params, config) => {
  const dataStr = qs.stringify(params, {
    arrayFormat: "indices",
    allowDots: true
  });
  return axios.post(url, dataStr, config);
};

export default axios;
