import axios from "./axios";

export default {
  // 修改密码
  passwordModify(data) {
    return axios.postRequest("/pwd/update", data);
  },

  // 权限管理列表
  permissionsManageList(data) {
    return axios.getRequest("/right/show", data);
  },

  // 权限管理录入
  enteringConfirm(data) {
    return axios.postRequest("/account/add", data);
  },

  // 权限管理修改展示
  changeShow(data) {
    return axios.getRequest("/right/detail", data);
  },

  // 权限管理修改
  changeConfirm(data) {
    return axios.postRequest("/right/update", data);
  },

  // 权限管理删除
  deleteConfirm(data) {
    return axios.getRequest("/right/delete", data);
  },
};
