import axios from "./axios";

export default {
  // 教师综合查询
  teacherTotalList(data) {
    return axios.getRequest("/teacher_research_total/show", data);
  },

  // 部门综合查询
  departmentTotalList(data) {
    return axios.getRequest("/department_research_total/show", data);
  },
};
