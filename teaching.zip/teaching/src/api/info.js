import axios from "./axios";

export default {

  // 课程录入
  enteringCourse(data) {
    return axios.postRequest("/course/add", data);
  },

  // 一键指派
  assignConfirm(data) {
    return axios.getRequest("/course/assign", data);
  },

  // 课程修改展示
  changeShow(data) {
    return axios.getRequest("/course/detail", data);
  },

  // 课程修改
  changeConfirm(data) {
    return axios.postRequest("/course/update", data);
  },

  // 课程删除
  deleteConfirm(data) {
    return axios.getRequest("/course/delete", data);
  },

  // 教室信息列表
  classroomInfoManageList(data) {
    return axios.getRequest("/classroom/show", data);
  },

  // 教室信息录入
  classroomEnteringConfirm(data) {
    return axios.postRequest("/classroom/add", data);
  },

  // 教室信息修改 - 展示
  classroomChangeShow(data) {
    return axios.getRequest("/classroom/detail", data);
  },

  // 教室信息修改
  classroomChangeConfirm(data) {
    return axios.postRequest("/classroom/update", data);
  },

  // 教室信息删除
  classroomDeleteConfirm(data) {
    return axios.getRequest("/classroom/delete", data);
  },

  // 教师部门列表
  departmentAll(data) {
    return axios.getRequest("/department/get/all", data);
  },

  // 教师信息录入
  teacherEntering(data) {
    return axios.postRequest("/teacher/add", data);
  },

  // 教师信息管理列表
  teacherInfoManageList(data) {
    return axios.getRequest("/teacher/show", data);
  },

  // 教师信息管理修改 - 展示
  teacherInfoManageListShow(data) {
    return axios.getRequest("/teacher/detail", data);
  },

  // 教师信息管理列表修改
  teacherInfoManageListChange(data) {
    return axios.postRequest("/teacher/update", data);
  },

  // 教师信息管理列表删除
  teacherInfoManageListDelete(data) {
    return axios.getRequest("/teacher/delete", data);
  },

};
