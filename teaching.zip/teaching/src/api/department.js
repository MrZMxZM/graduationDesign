import axios from "./axios";

export default {
  // 部门信息列表
  departmentList(data) {
    return axios.getRequest("/department/show", data);
  },

  //部门信息录入
  departmentEntering(data) {
    return axios.postRequest("/department/add", data);
  },

  //部门信息修改展示
  departmentChangeShow(data) {
    return axios.getRequest("/department/detail", data);
  },

  //部门信息修改
  departmentChange(data) {
    return axios.postRequest("/department/update", data);
  },

  //部门信息删除
  departmentDelete(data) {
    return axios.getRequest("/department/delete", data);
  }
};