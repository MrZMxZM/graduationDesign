import axios from "./axios";

export default {
  // 教研项目列表
  subjectList(data) {
    return axios.getRequest("/research_project/show", data);
  },

  // 教研项目申请
  subjectApply(data) {
    return axios.postRequest("/research_project/add", data);
  },

  // 教研项目审核展示
  subjectAuditShow(data) {
    return axios.getRequest("/research_project/detail", data);
  },

  // 教研项目审核
  subjectAudit(data) {
    return axios.postRequest("/research_project/update", data);
  },

  // 教研论文列表
  paperList(data) {
    return axios.getRequest("/research_paper/show", data);
  },

  // 教研论文申请
  applyConfirm(data) {
    return axios.postRequest("/research_paper/add", data);
  },

  // 教研论文审核展示
  auditShow(data) {
    return axios.getRequest("/research_paper/detail", data);
  },

  // 教研论文审核
  auditConfirm(data) {
    return axios.postRequest("/research_paper/update", data);
  },

  // 优秀课列表
  perfectCourseList(data) {
    return axios.getRequest("/perfect_course/show", data);
  },

  // 优秀课申请
  courseApplyConfirm(data) {
    return axios.postRequest("/perfect_course/add", data);
  },

  // 优秀课审核展示
  courseAuditShow(data) {
    return axios.getRequest("/perfect_course/detail", data);
  },

  // 优秀课审核
  courseAuditConfirm(data) {
    return axios.postRequest("/perfect_course/update", data);
  },

  // 学科竞赛列表
  competitionList(data) {
    return axios.getRequest("/competition/show", data);
  },

  // 学科竞赛申请
  applyCompetition(data) {
    return axios.postRequest("/competition/add", data);
  },

  // 学科竞赛审核展示
  auditCompetitionShow(data) {
    return axios.getRequest("/competition/detail", data);
  },

  // 学科竞赛审核
  auditCompetition(data) {
    return axios.postRequest("/competition/update", data);
  },
};
