<template>
  <div class="header">
    <img src="https://gss1.bdstatic.com/9vo3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike92%2C5%2C5%2C92%2C30/sign=af2771fcd9160924c828aa49b56e5e9f/7acb0a46f21fbe0972b9d5be62600c338644adb0.jpg" width="67px" height="50px" />
    <span class="title">{{ $t("北华大学教研管理平台") }}</span>
    <span>{{ $t("您好") + ": " + managerName}}-{{role}}</span>
    <span class="logout" @click.stop="logout">{{ $t("退出登录") }}</span>
<!--    <el-dropdown class="language" @command="chooseLanguage">-->
<!--      <span>Language</span>-->
<!--      <el-dropdown-menu slot="dropdown">-->
<!--        <el-dropdown-item command="en">English</el-dropdown-item>-->
<!--        <el-dropdown-item command="zh">中文</el-dropdown-item>-->
<!--      </el-dropdown-menu>-->
<!--    </el-dropdown>-->
  </div>
</template>

<script>
export default {
  name: "MHeader",
  data() {
    return {
      managerName: localStorage.getItem("managerName"),
      right:localStorage.getItem("right"),
      role: ""
    };
  },

  created() {
    this.$root.$on("getManagerName", () => {
      this.managerName = localStorage.getItem("managerName");
    });
    this.checkRight();
  },
  methods: {
    chooseLanguage(lang) {
      this.$i18n.locale = lang;
    },
    logout() {
      localStorage.clear();
      this.$router.replace({
        name: "login"
      });
    },
    checkRight() {
      if(this.right.includes("save") && this.right.includes("role")) {
        return this.role = this.$t("管理员")
      }else if(this.right.includes("save") && this.right.includes("delete")) {
        return this.role = this.$t("教师")
      }else if(this.right.includes("save")) {
        return this.role = this.$t("学生")
      }
    }
  }
};
</script>

<style scoped lang="scss">
.header {
  background: teal;
  display: flex;
  align-items: center;
  color: #fff;

  .title {
    flex-grow: 1;
    padding-left: 20px;
    font-size: 1.2rem;
  }

  .change-pwd,
  .logout {
    cursor: pointer;
    padding: 20px;
  }

  .language {
    cursor: pointer;
    padding: 20px;
    color: #fff;
  }
}
</style>
