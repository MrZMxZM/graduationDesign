import Vue from "vue";

import MHeader from "./MHeader";

const components = {
  MHeader
};

Object.keys(components).forEach(key => {
  Vue.component(key, components[key]);
});
