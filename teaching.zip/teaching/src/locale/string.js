const locales = ["zh", "en", "id"];
const strings = {
  你好: ["你好", "Hello", "Halo"]
};

export { locales, strings };
