import Vue from "vue";
import VueI18n from "vue-i18n";
import { locales, strings } from "./string";
import { seperateMessages } from "./util";

Vue.use(VueI18n);

let locale = "zh";

const messages = seperateMessages(strings, locales);
const i18n = new VueI18n({
  locale: locales.indexOf(locale) > -1 ? locale : "id",
  messages,
  silentTranslationWarn: true
});

export default i18n;
