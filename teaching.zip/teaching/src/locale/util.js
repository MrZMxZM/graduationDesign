/**
 * 将string.js中的strings对象分割成vue-i18n的输入对象
 * @param mixedMessages 不同语言的字符串集合，string.js中的strings对象
 * @param locales 语言的标识符，string.js中的locales对象
 * @returns {{}} vue-i18n中的messages参数要求对象，形如：{en, zh}
 */
export function seperateMessages(mixedMessages, locales) {
  let result = {};

  /**
   * 递归遍历对象，获取指定索引的值并组成新对象
   * @param obj 待遍历对象
   * @param index 目标索引
   * @returns {*}
   * @private
   */
  let _tranverseByIndex = function(obj, index) {
    let _retObj = {};
    if (obj instanceof Array) {
      if (obj[index]) {
        return obj[index];
      } else {
        return obj[0];
      }
    } else if (typeof obj === "object") {
      for (let _key in obj) {
        try {
          _retObj[_key] = _tranverseByIndex(obj[_key], index);
        } catch (e) {
          console.error("Index out of range : At " + _key);
          throw e;
        }
      }
    } else {
      throw new Error(index);
    }
    return _retObj;
  };

  if (locales instanceof Array) {
    locales.forEach((locale, index) => {
      result[locale] = _tranverseByIndex(mixedMessages, index);
    });
  } else {
    throw new Error("Illegal locales");
  }
  return result;
}
