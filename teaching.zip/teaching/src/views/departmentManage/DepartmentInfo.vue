<template>
    <div class="department-info">
        <div class="search">
            <div class="header">
                <i class="el-icon-search"></i>
                <span class="title">{{ $t("筛选查询") }}</span>
                <span class="confirm" @click="filterM">{{ $t("筛选") }}</span>
                <span class="reset" @click="reset">{{ $t("重置") }}</span>
                <span v-if="right.includes('role')" class="reset" @click="enteringDialogVisible = true">{{ $t("录入") }}</span>
            </div>

            <el-form
                    ref="filter"
                    :model="filter"
                    label-suffix=":"
                    label-position="left"
                    inline
            >

                <el-form-item :label="$t('部门编号')" prop="department_number">
                    <el-input v-model="filter.department_number"></el-input>
                </el-form-item>

                <el-form-item :label="$t('部门名称')" prop="department_name">
                    <el-input v-model="filter.department_name"></el-input>
                </el-form-item>
            </el-form>
        </div>

        <div class="main">
            <el-table :data="data" stripe border>

                <el-table-column
                        :label="$t('部门编号')"
                        prop="department_number"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('部门名称')"
                        prop="department_name"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('操作')"
                        align="center"
                        v-if="right.includes('role')"
                >
                    <template slot-scope="scope">
                        <el-button type="text" size="small" @click="changeShow(scope.row.department_number)">
                            {{ $t("修改") }}
                        </el-button>

                        <el-button type="text" size="small" @click="isDel(scope.row.department_number)">
                            {{ $t("删除") }}
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>

        <div class="footer">
            <el-pagination
                    layout="total, sizes, prev, pager, next, jumper"
                    :page-sizes= "[1,5,10,15,20]"
                    :total="size"
                    :page-size.sync="filter.pageSize"
                    :current-page.sync="filter.currPage"
                    background
                    @size-change="pageChange"
                    @current-change="pageChange"
            >
            </el-pagination>
        </div>

        <el-dialog
                :title="$t('录入部门信息')"
                :visible.sync="enteringDialogVisible"
                @close="clearDate"
                center
                class="entering"
        >
            <el-form
                    ref="enteringForm"
                    :model="enteringForm"
                    label-suffix=":"
                    label-position="right"
                    label-width="100px"
            >
                <el-form-item :label="$t('部门编号')" prop="department_number">
                    <el-input v-model="enteringForm.department_number"></el-input>
                </el-form-item>

                <el-form-item :label="$t('部门名称')" prop="department_name">
                    <el-input v-model="enteringForm.department_name"></el-input>
                </el-form-item>
            </el-form>

            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="enteringLoading"
                        @click="departmentEntering"
                >
                  {{ $t("确认录入") }}
                </el-button>

                <el-button @click="enteringDialogVisible = false;">
                  {{ $t("取消") }}
                </el-button>
            </span>
        </el-dialog>

        <el-dialog
                :title="$t('修改部门信息')"
                :visible.sync="changeDialogVisible"
                center
                class="change"
                @close="clearDate"
        >
            <el-form
                    ref="changeForm"
                    :model="changeForm"
                    label-suffix=":"
                    label-position="right"
                    label-width="100px"
            >
                <el-form-item :label="$t('部门编号')" prop="department_number">
                    <el-input v-model="changeForm.department_number" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('部门名称')" prop="department_name">
                    <el-input v-model="changeForm.department_name"></el-input>
                </el-form-item>
            </el-form>

            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="changeLoading"
                        @click="changeConfirm"
                >
                  {{ $t("确认修改") }}
                </el-button>

                <el-button @click="changeDialogVisible = false;">
                  {{ $t("取消") }}
                </el-button>
            </span>
        </el-dialog>

        <el-dialog
                :title="$t('删除部门信息')"
                :visible.sync="deleteDialogVisible"
                center
        >
            <div class="text-center">{{ $t("确认删除此条部门信息?") }}</div>
            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="deleteLoading"
                        @click="deleteConfirm"
                >
                  {{ $t("确认删除") }}
                </el-button>

                <el-button @click="deleteDialogVisible = false;">
                  {{ $t("取消") }}
                </el-button>
                </span>
        </el-dialog>
    </div>
</template>

<script>
  import departmentApi from "@/api/department";

  export default {
    name: "DepartmentInfo",
    data() {
      return {
        size: 0,
        filter: {
          pageSize: 10,
          currPage: 1,
          department_number: "",
          department_name: "",
        },
        data: [],
        enteringForm: {
          department_number: "",
          department_name: "",
        },
        changeForm: {
          department_number: "",
          department_name: "",
        },
        deleteNum: "",
        right: localStorage.getItem("right"),
        enteringDialogVisible: false,
        changeDialogVisible: false,
        deleteDialogVisible: false,
        enteringLoading: false,
        changeLoading: false,
        deleteLoading: false,
      };
    },
    created() {
      this.departmentList();
    },
    methods: {
      departmentList() {
        departmentApi
          .departmentList(this.filter)
          .then(data => {
            this.data = data.list;
            this.size = data.size;
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
      departmentEntering() {
        departmentApi
          .departmentEntering(this.enteringForm)
          .then(data => {
            this.enteringDialogVisible = false;
            this.$message.success(this.$t("录入成功"));
            this.departmentList();
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
      changeShow(department_number) {
        this.changeDialogVisible = true;
        departmentApi
          .departmentChangeShow({department_number})
          .then(data => {
            this.changeForm = data;
          })
          .catch(e => {
            this.$message.error(this.$t(e))
          })
      },
      changeConfirm() {
        this.changeLoading = true;
        departmentApi
          .departmentChange(this.changeForm)
          .then(data => {
            this.changeLoading = false;
            this.changeDialogVisible = false;
            this.$message.success(this.$t("修改成功"));
            this.departmentList();
          })
          .catch(e => {
            this.changeLoading = false;
            this.$message.error(this.$t(e));
          });
      },
      isDel(department_number) {
        this.deleteDialogVisible = true;
        this.deleteNum = department_number;
      },
      deleteConfirm() {
        this.deleteLoading = true;
        departmentApi
          .departmentDelete({department_number: this.deleteNum})
          .then(data => {
            this.deleteLoading = false;
            this.deleteDialogVisible = false;
            this.$message.success(this.$t("删除成功"));
            this.departmentList();
          })
          .catch(e => {
            this.deleteLoading = false;
            this.$message.error(this.$t(e));
          });
      },
      clearDate() {
        this.enteringForm = {
          department_number: "",
          department_name: "",
        },
        this.changeForm = {
          department_number: "",
          department_name: "",
        }
      },
      filterM() {
        this.filter.currPage = 1;
        this.departmentList();
      },
      reset() {
        this.filter = {
          pageSize: 10,
          currPage: 1,
          department_number: "",
          department_name: "",
        };
        this.departmentList();
      },
      pageChange(val) {
        this.filter.currPage = val;
        this.departmentList();
      }
    }
  };
</script>

<style scoped lang="scss">
    .department-info {
        height: 100%;
        display: flex;
        flex-direction: column;

        .text-center {
            text-align: center;
        }

        .el-input {
            width: 150px;
        }

        .el-select {
            width: 150px;
        }

        .search {
            .header {
                display: flex;
                background: whitesmoke;
                border: 1px solid #e3e3e3;
                border-bottom: 1px solid whitesmoke;

                .title {
                    flex-grow: 1;
                }

                i {
                    padding: 20px 5px 20px 20px;
                }

                span {
                    padding: 20px 20px 20px 0;
                }

                .confirm,
                .reset {
                    color: teal;
                    cursor: pointer;
                }
            }

            .el-form {
                border: 1px solid #f3f3f3;
                padding: 20px;
            }
        }

        .main {
            flex-grow: 1;
            padding: 20px 0 60px;

            .el-button {
                margin: 5px;
            }
        }

        .footer {
            position: relative;

            .el-pagination {
                position: absolute;
                right: 0;
                bottom: 10px;
            }
        }

        .entering,
        .change {

            /deep/ {

                .el-dialog__body {
                    height: 70px;
                    .el-form {

                        .el-form-item {
                            float: left;
                            width: 300px;
                        }
                    }
                }
            }
        }
    }
</style>
