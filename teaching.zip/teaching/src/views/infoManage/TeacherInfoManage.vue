<template>
    <div class="teacher-info-manage">
        <div class="search">
            <div class="header">
                <i class="el-icon-search"></i>
                <span class="title">{{ $t("筛选查询") }}</span>
                <span class="confirm" @click="filterM">{{ $t("筛选") }}</span>
                <span class="reset" @click="reset">{{ $t("重置") }}</span>
                <span v-if="right.includes('role')" class="reset" @click="enteringDialogVisible = true">{{ $t("录入") }}</span>
            </div>

            <el-form
                    ref="filter"
                    :model="filter"
                    label-suffix=":"
                    label-position="left"
                    inline
            >
                <el-form-item :label="$t('教师姓名')" prop="name">
                    <el-input v-model="filter.name"></el-input>
                </el-form-item>

                <el-form-item :label="$t('教师编号')" prop="number">
                    <el-input v-model="filter.number"></el-input>
                </el-form-item>

                <el-form-item :label="$t('性别')" prop="gender">
                    <el-select v-model="filter.gender">
                        <el-option value="" :label="$t('全部')"></el-option>
                        <el-option value="0" :label="$t('女')"></el-option>
                        <el-option value="1" :label="$t('男')"></el-option>
                    </el-select>
                </el-form-item>

                <el-form-item :label="$t('部门编号')" prop="department_number">
                    <el-input v-model="filter.department_number"></el-input>
                </el-form-item>

                <el-form-item :label="$t('部门名称')" prop="department_name">
                    <el-input v-model="filter.department_name"></el-input>
                </el-form-item>

                <el-form-item :label="$t('毕业院校')" prop="graduate">
                    <el-input v-model="filter.graduate"></el-input>
                </el-form-item>

                <el-form-item :label="$t('手机号')" prop="mobile">
                    <el-input v-model="filter.mobile"></el-input>
                </el-form-item>
            </el-form>
        </div>

        <div class="main">
            <el-table :data="data" stripe border>

                <el-table-column
                        :label="$t('教师编号')"
                        prop="number"
                        align="center"
                ></el-table-column>

                <el-table-column
                        :label="$t('职称')"
                        prop="title"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('姓名')"
                        prop="name"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('性别')"
                        prop="gender"
                        align="center"
                >
                    <template slot-scope="scope">
                        {{scope.row.gender ? $t("男"):$t("女")}}
                    </template>
                </el-table-column>

                <el-table-column
                        :label="$t('部门编号')"
                        prop="department_number"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('部门名称')"
                        prop="department_name"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('手机号')"
                        prop="mobile"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('出生日期')"
                        prop="birthday"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('毕业院校')"
                        prop="graduate"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('操作')"
                        align="center"
                        v-if="right.includes('role')"
                >
                    <template slot-scope="scope">
                        <el-button type="text" size="small" @click="changeShow(scope.row.number)">
                            {{ $t("修改") }}
                        </el-button>

                        <el-button type="text" size="small" @click="isDel(scope.row.number)">
                            {{ $t("删除") }}
                        </el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>

        <div class="footer">
            <el-pagination
                    layout="total, sizes, prev, pager, next, jumper"
                    :page-sizes= "[1,5,10,15,20]"
                    :total="size"
                    :page-size.sync="filter.pageSize"
                    :current-page.sync="filter.currPage"
                    background
                    @size-change="pageChange"
                    @current-change="pageChange"
            >
            </el-pagination>
        </div>

        <el-dialog
                :title="$t('录入教师信息')"
                :visible.sync="enteringDialogVisible"
                center
                class="entering"
        >
            <el-form
                    ref="enteringForm"
                    :model="enteringForm"
                    label-suffix=":"
                    label-position="right"
                    label-width="100px"
            >
                <el-form-item :label="$t('教师编号')" prop="number">
                    <el-input v-model="enteringForm.number"></el-input>
                </el-form-item>

                <el-form-item :label="$t('姓名')" prop="name">
                    <el-input v-model="enteringForm.name"></el-input>
                </el-form-item>

                <el-form-item :label="$t('职称')" prop="title">
                    <el-input v-model="enteringForm.title"></el-input>
                </el-form-item>

<!--                <el-form-item :label="$t('部门编号')" prop="department_number">-->
<!--                    <el-input v-model="enteringForm.department_number"></el-input>-->
<!--                </el-form-item>-->

<!--                <el-form-item :label="$t('部门名称')" prop="department_name">-->
<!--                    <el-input v-model="enteringForm.department_name"></el-input>-->
<!--                </el-form-item>-->

<!--                <el-form-item :label="$t('部门编号')" prop="department_number">-->
<!--                    <el-select v-model="enteringForm.department_number">-->
<!--                        <el-option-->
<!--                                v-for="item in departmentList"-->
<!--                                :key="item.department_name"-->
<!--                                :value="item.department_number"-->
<!--                                :label="item.department_number"-->
<!--                        >-->
<!--                        </el-option>-->
<!--                    </el-select>-->
<!--                </el-form-item>-->

                <el-form-item :label="$t('部门名称')" prop="department_name">
                    <el-select v-model="enteringForm.department_name">
                        <el-option
                                v-for="item in departmentList"
                                :key="item.department_number"
                                :value="item.department_name"
                                :label="item.department_name"
                        >
                        </el-option>
                    </el-select>
                </el-form-item>

                <el-form-item :label="$t('性别')" prop="gender">
                    <el-select v-model="enteringForm.gender">
                        <el-option value="1" :label="$t('男')"></el-option>
                        <el-option value="0" :label="$t('女')"></el-option>
                    </el-select>
                </el-form-item>

                <el-form-item :label="$t('手机号')" prop="mobile">
                    <el-input v-model="enteringForm.mobile"></el-input>
                </el-form-item>

                <el-form-item :label="$t('出生日期')" prop="birthday">
                    <el-input v-model="enteringForm.birthday"></el-input>
                </el-form-item>

                <el-form-item :label="$t('毕业院校')" prop="graduate">
                    <el-input v-model="enteringForm.graduate"></el-input>
                </el-form-item>
            </el-form>

            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="enteringLoading"
                        @click="teacherEntering"
                >
                  {{ $t("确认录入") }}
                </el-button>

                <el-button @click="enteringDialogVisible = false;">
                  {{ $t("取消") }}
                </el-button>
            </span>
        </el-dialog>

        <el-dialog
                :title="$t('修改教师信息')"
                :visible.sync="changeDialogVisible"
                center
                class="change"
                @close="clearDate"
        >
            <el-form
                    ref="changeForm"
                    :model="changeForm"
                    label-suffix=":"
                    label-position="right"
                    label-width="100px"
            >
                <el-form-item :label="$t('教师编号')" prop="number">
                    <el-input v-model="changeForm.number" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('姓名')" prop="name">
                    <el-input v-model="changeForm.name"></el-input>
                </el-form-item>

                <el-form-item :label="$t('职称')" prop="title">
                    <el-input v-model="changeForm.title"></el-input>
                </el-form-item>

<!--                <el-form-item :label="$t('部门编号')" prop="department_number">-->
<!--                    <el-input v-model="changeForm.department_number"></el-input>-->
<!--                </el-form-item>-->

<!--                <el-form-item :label="$t('部门名称')" prop="department_name">-->
<!--                    <el-input v-model="changeForm.department_name"></el-input>-->
<!--                </el-form-item>-->

<!--                <el-form-item :label="$t('部门编号')" prop="department_number">-->
<!--                    <el-select v-model="changeForm.department_number">-->
<!--                        <el-option-->
<!--                                v-for="item in departmentList"-->
<!--                                :key="item.department_name"-->
<!--                                :value="item.department_number"-->
<!--                                :label="item.department_number"-->
<!--                        >-->
<!--                        </el-option>-->
<!--                    </el-select>-->
<!--                </el-form-item>-->

                <el-form-item :label="$t('部门名称')" prop="department_name">
                    <el-select v-model="changeForm.department_name">
                        <el-option
                                v-for="item in departmentList"
                                :key="item.department_number"
                                :value="item.department_name"
                                :label="item.department_name"
                        >
                        </el-option>
                    </el-select>
                </el-form-item>

                <el-form-item :label="$t('性别')" prop="gender">
                    <el-select v-model="changeForm.gender">
                        <el-option value="1" :label="$t('男')"></el-option>
                        <el-option value="0" :label="$t('女')"></el-option>
                    </el-select>
                </el-form-item>

                <el-form-item :label="$t('手机号')" prop="mobile">
                    <el-input v-model="changeForm.mobile"></el-input>
                </el-form-item>

                <el-form-item :label="$t('出生日期')" prop="birthday">
                    <el-input v-model="changeForm.birthday"></el-input>
                </el-form-item>

                <el-form-item :label="$t('毕业院校')" prop="graduate">
                    <el-input v-model="changeForm.graduate"></el-input>
                </el-form-item>
            </el-form>

            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="changeLoading"
                        @click="changeConfirm"
                >
                  {{ $t("确认修改") }}
                </el-button>

                <el-button @click="changeDialogVisible = false;">
                  {{ $t("取消") }}
                </el-button>
            </span>
        </el-dialog>

        <el-dialog
                :title="$t('删除教师信息')"
                :visible.sync="deleteDialogVisible"
                center
        >
            <div class="text-center">{{ $t("确认删除此条教师信息?") }}</div>
            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="deleteLoading"
                        @click="deleteConfirm"
                >
                  {{ $t("确认删除") }}
                </el-button>

                <el-button @click="deleteDialogVisible = false;">
                  {{ $t("取消") }}
                </el-button>
                </span>
        </el-dialog>
    </div>
</template>

<script>
  import infoApi from "@/api/info";

  export default {
    name: "TeacherInfoManage",
    data() {
      return {
        size: 0,
        filter: {
          pageSize: 10,
          currPage: 1,
          name: "",
          number: "",
          gender: "",
          mobile: "",
          graduate: "",
          department_number: "",
          department_name: "",
        },
        data: [],
        enteringForm: {
          number: "",
          name: "",
          gender: "",
          mobile: "",
          graduate: "",
          department_number: "",
          department_name: "",
          title: "",
          birthday: "",

        },
        changeForm: {
          number: "",
          name: "",
          gender: "",
          mobile: "",
          graduate: "",
          department_number: "",
          department_name: "",
          title: "",
          birthday: "",
        },
        departmentList: [],
        deleteNum: "",
        right: localStorage.getItem("right"),
        enteringDialogVisible: false,
        changeDialogVisible: false,
        deleteDialogVisible: false,
        enteringLoading: false,
        changeLoading: false,
        deleteLoading: false,
      };
    },
    created() {
      this.teacherInfoManageList();
      this.departmentAll();
    },
    methods: {
      teacherInfoManageList() {
        infoApi
          .teacherInfoManageList(this.filter)
          .then(data => {
            this.data = data.list;
            this.size = data.size;
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
      teacherEntering() {
        infoApi
          .teacherEntering(this.enteringForm)
          .then(data => {
            this.enteringDialogVisible = false;
            this.$message.success(this.$t("录入成功"));
            this.teacherInfoManageList();
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
      changeShow(number) {
        this.changeDialogVisible = true;
        infoApi
          .teacherInfoManageListShow({number})
          .then(data => {
            this.changeForm = data;
          })
          .catch(e => {
            this.$message.error(this.$t(e))
          })
      },
      departmentAll() {
        infoApi
          .departmentAll()
          .then(data => {
            this.departmentList = data;
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          })
      },
      changeConfirm() {
        this.changeLoading = true;
        infoApi
          .teacherInfoManageListChange(this.changeForm)
          .then(data => {
            this.changeLoading = false;
            this.changeDialogVisible = false;
            this.$message.success(this.$t("修改成功"));
            this.teacherInfoManageList();
          })
          .catch(e => {
            this.changeLoading = false;
            this.$message.error(this.$t(e));
          });
      },
      isDel(number) {
        this.deleteDialogVisible = true;
        this.deleteNum = number;
      },
      deleteConfirm() {
        this.deleteLoading = true;
        infoApi
          .teacherInfoManageListDelete({number: this.deleteNum})
          .then(data => {
            this.deleteLoading = false;
            this.deleteDialogVisible = false;
            this.$message.success(this.$t("删除成功"));
            this.teacherInfoManageList();
          })
          .catch(e => {
            this.deleteLoading = false;
            this.$message.error(this.$t(e));
          });
      },
      clearDate() {
        this.changeForm = {
          number: "",
          name: "",
          gender: "",
          mobile: "",
          graduate: "",
          department_number: "",
          department_name: "",
          title: "",
          birthday: "",
        }
      },
      filterM() {
        this.filter.currPage = 1;
        this.teacherInfoManageList();
      },
      reset() {
        this.filter = {
          pageSize: 10,
          currPage: 1,
          name: "",
          number: "",
          gender: "",
          mobile: "",
          graduate: "",
          department_number: "",
          department_name: "",
        };
        this.teacherInfoManageList();
      },
      pageChange(val) {
        this.filter.currPage = val;
        this.teacherInfoManageList();
      }
    }
  };
</script>

<style scoped lang="scss">
    .teacher-info-manage {
        height: 100%;
        display: flex;
        flex-direction: column;

        .text-center {
            text-align: center;
        }

        .el-input {
            width: 150px;
        }

        .el-select {
            width: 150px;
        }

        .search {
            .header {
                display: flex;
                background: whitesmoke;
                border: 1px solid #e3e3e3;
                border-bottom: 1px solid whitesmoke;

                .title {
                    flex-grow: 1;
                }

                i {
                    padding: 20px 5px 20px 20px;
                }

                span {
                    padding: 20px 20px 20px 0;
                }

                .confirm,
                .reset {
                    color: teal;
                    cursor: pointer;
                }
            }

            .el-form {
                border: 1px solid #f3f3f3;
                padding: 20px;
            }
        }

        .main {
            flex-grow: 1;
            padding: 20px 0 60px;

            .el-button {
                margin: 5px;
            }
        }

        .footer {
            position: relative;

            .el-pagination {
                position: absolute;
                right: 0;
                bottom: 10px;
            }
        }

        .entering,
        .change {

            /deep/ {

                .el-dialog__body {
                    height: 300px;
                    .el-form {

                        .el-form-item {
                            float: left;
                            width: 300px;
                        }
                    }
                }
            }
        }
    }
</style>
