<template>
  <div class="home">
    <m-header></m-header>
    <el-tabs v-model="activeName" type="border-card" @tab-click="handleClick">
      <el-tab-pane :label="$t('教师信息管理')" name="info">
        <router-view></router-view>
      </el-tab-pane>
      <el-tab-pane :label="$t('部门信息管理')" name="department">
        <router-view></router-view>
      </el-tab-pane>
      <el-tab-pane :label="$t('教研成果管理')" name="student">
        <router-view></router-view>
      </el-tab-pane>
      <el-tab-pane :label="$t('综合统计查询')" name="search">
        <router-view></router-view>
      </el-tab-pane>
      <el-tab-pane :label="$t('系统管理')" name="system">
        <router-view></router-view>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
export default {
  name: "Home",
  data() {
    return {
      activeName: "info"
    };
  },
  created() {
    this.$router.replace({ name: this.activeName });
  },
  methods: {
    handleClick() {
      this.$router.replace({ name: this.activeName });
    }
  }
};
</script>

<style lang="scss">
.home {
  height: 100%;

  .el-tabs {
    height: calc(100% - 60px);

    .el-tabs__content {
      height: calc(100% - 40px);
      padding: 0;

      .el-tab-pane {
        height: 100%;
      }
    }
  }
}
</style>
