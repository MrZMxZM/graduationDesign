<template>
  <div class="info">
    <el-container>
      <el-aside width="200px">
        <el-menu :default-active="$route.path" router>
          <el-menu-item v-if="right.includes('teacher')" index="/info/teacherInfoManage">
            <span slot="title">{{ $t("教师信息管理") }}</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-main> <router-view></router-view> </el-main>
    </el-container>
  </div>
</template>

<script>
  export default {
    name: "Info",
    data() {
      return {
        right: localStorage.getItem("right")
      }
    }
  };
</script>

<style scoped lang="scss">
  .info {
    height: 100%;

    .el-container {
      height: 100%;
    }
  }
</style>
