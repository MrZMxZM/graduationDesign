<template>
  <div class="login">
    <div class="main">
      <div class="title">北华大学高校教研管理平台系统</div>
      <el-form
        ref="form"
        :model="form"
        :rules="rules"
        label-width="100px"
        label-suffix=":"
        label-position="right"
      >
        <el-form-item label="用户类型" prop="type">
         <el-radio-group v-model="form.type">
           <el-radio :label="1">{{ $t('教师') }}</el-radio>
           <el-radio :label="2">{{ $t('管理员') }}</el-radio>
         </el-radio-group>
        </el-form-item>

        <el-form-item label="账号" prop="account">
          <el-input
            v-model="form.account"
            :placeholder="$t('身份证号')"
            @keyup.enter.native="login"
          ></el-input>
        </el-form-item>

        <el-form-item label="密码" prop="pwd">
          <el-input
            v-model="form.pwd"
            type="password"
            :placeholder="$t('请输入密码')"
            @keyup.enter.native="login"
          ></el-input>
        </el-form-item>

        <el-form-item class="logining">
          <el-button
            type="primary"
            :disabled="!form.account || !form.pwd"
            @click="login"
          >登录</el-button
          >
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
  import userApi from "@/api/user";

  export default {
    name: "Login",
    data() {
      return {
        form: {
          type: 1,
          account: "",
          pwd: ""
        },
        rules: {
          account: [{ required: true, message: "请输入账号" }],
          pwd: [{ required: true, message: "请输入登录密码" }],
        }
      };
    },
    methods: {
      login() {
        this.$refs.form.validate(valid => {
          if (valid) {
            userApi
              .login(this.form)
              .then(data => {
                if(data.token) {
                  this.$message.success("登录成功");
                  localStorage.setItem("token", data.token);
                  localStorage.setItem("managerName", this.form.account);
                  localStorage.setItem("right", data.right);
                  console.log(1111,data.right)
                  this.$router.replace({
                    name: "home"
                  });
                }
              })
              .catch(e => {
                this.$message.error(this.$t("账号或密码不正确，请检查后重新输入"));
              });
          }
        });
      },
    }
  };
</script>

<style scoped lang="scss">
  .login {

    .main {
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 500px;
      padding: 20px 40px 20px 40px;
      box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.1);
      border-radius: 5px;
      border: 1px solid #e6e6e6;

      .title {
        padding-bottom: 30px;
      }
      .el-form {
        position: relative;
        .el-input {
          width: 300px;
        }
      }
      .row {
        text-align: right;
        .forget-password {
          font-size: 0.5rem;
        }
      }
      .logining {

        .el-button {
          width: 300px;
          margin-top: 10px;
        }
      }
    }
  }
</style>
