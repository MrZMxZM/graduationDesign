<template>
  <div class="results-info">
    <div class="search">
      <div class="header">
        <i class="el-icon-search"></i>
        <span class="title">{{ $t("筛选查询") }}</span>
        <span class="confirm" @click="filterM">{{ $t("筛选") }}</span>
        <span class="reset" @click="reset">{{ $t("重置") }}</span>
      </div>

      <el-form
        ref="filter"
        :model="filter"
        label-suffix=":"
        label-position="left"
        inline
      >
        <el-form-item :label="$t('姓名')" prop="name">
          <el-input v-model="filter.stu_name"></el-input>
        </el-form-item>

        <el-form-item :label="$t('学号')" prop="contractNo">
          <el-input v-model="filter.stu_number"></el-input>
        </el-form-item>

        <el-form-item :label="$t('班级')" prop="mobile">
          <el-input v-model="filter.stu_classes"></el-input>
        </el-form-item>

        <el-form-item :label="$t('课程名')" prop="mobile">
          <el-input v-model="filter.test_name"></el-input>
        </el-form-item>
      </el-form>
    </div>

    <div class="main">
      <el-table :data="data" stripe border>

        <el-table-column
                :label="$t('考试名称')"
                prop="test_name"
                align="center"
        >
        </el-table-column>

        <el-table-column
          :label="$t('学号')"
          prop="stu_number"
          align="center"
        >
        </el-table-column>

        <el-table-column
          :label="$t('姓名')"
          prop="stu_name"
          align="center"
        >
        </el-table-column>

        <el-table-column
          :label="$t('班级')"
          prop="stu_classes"
          align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('操作')"
                align="center"
        >
          <template slot-scope="scope">
            <el-button type="text" size="small" @click="detail(scope.row.stu_number, scope.row.test_name)">
              {{ $t("查看详情") }}
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>

    <div class="footer">
      <el-pagination
              layout="total, sizes, prev, pager, next, jumper"
              :page-sizes= "[1,5,10,15,20]"
              :total="size"
              :page-size.sync="filter.pageSize"
              :current-page.sync="filter.currPage"
              background
              @size-change="pageChange"
              @current-change="pageChange"
      >
      </el-pagination>
    </div>

    <results-info-detail
      v-if="isOpen"
      @close="detail"
      :studentNum="studentNum"
      :testName="testName"
    >

    </results-info-detail>
  </div>
</template>

<script>
  import searchApi from "@/api/search";
  import ResultsInfoDetail from "./ResultsInfoDetail";

  export default {
    name: "ResultsInfo",
    components: { ResultsInfoDetail },
    data() {
      return {
        filter: {
          pageSize: 10,
          currPage: 1,
          stu_classes: "",
          stu_number: null,
          stu_name: "",
          test_name: "",
        },
        size: 0,
        data: [],
        studentNum: "",
        testName: "",
        isOpen: false
      };
    },
    created() {
      this.resultsInfoList();
    },
    methods: {
      detail(numVal, testVal) {
        this.isOpen = !this.isOpen;
        this.studentNum = numVal;
        this.testName = testVal;
      },
      resultsInfoList() {
        searchApi
          .resultsInfoList(this.filter)
          .then(data => {
            this.data = data.list;
            this.size = data.length;
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
      filterM() {
        this.filter.currPage = 1;
        this.resultsInfoList();
      },
      reset() {
        this.filter = {
          pageSize: 10,
          currPage: 1,
          stu_classes: "",
          stu_number: null,
          stu_name: "",
          test_name: "",
        };
        this.resultsInfoList();
      },
      pageChange(val) {
        // this.data =
        //   this.data &&
        //   this.data.slice(
        //     (this.currPage - 1) * this.pageSize,
        //     this.currPage * this.pageSize
        //   );
        this.filter.currPage = val;
        this.resultsInfoList();
      }
    }
  };
</script>

<style scoped lang="scss">
  .results-info {
    height: 100%;
    display: flex;
    flex-direction: column;

    .el-input {
      width: 150px;
    }

    .el-select {
      width: 150px;
    }

    .search {
      .header {
        display: flex;
        background: whitesmoke;
        border: 1px solid #e3e3e3;
        border-bottom: 1px solid whitesmoke;

        .title {
          flex-grow: 1;
        }

        i {
          padding: 20px 5px 20px 20px;
        }

        span {
          padding: 20px 20px 20px 0;
        }

        .confirm,
        .reset {
          color: teal;
          cursor: pointer;
        }
      }

      .el-form {
        border: 1px solid #f3f3f3;
        padding: 20px;
      }
    }

    .main {
      flex-grow: 1;
      padding: 20px 0 60px;

      .el-button {
        margin: 5px;
      }
    }

    .footer {
      position: relative;

      .el-pagination {
        position: absolute;
        right: 0;
        bottom: 10px;
      }
    }
  }
</style>
