<template>
  <div class="teachers-info">
    <div class="search">
      <div class="header">
        <i class="el-icon-search"></i>
        <span class="title">{{ $t("筛选查询") }}</span>
        <span class="confirm" @click="filterM">{{ $t("筛选") }}</span>
        <span class="reset" @click="reset">{{ $t("重置") }}</span>
      </div>

      <el-form
        ref="filter"
        :model="filter"
        label-suffix=":"
        label-position="left"
        inline
      >
        <el-form-item :label="$t('姓名')" prop="name">
          <el-input v-model="filter.name"></el-input>
        </el-form-item>

        <el-form-item :label="$t('职工号')" prop="number">
          <el-input v-model="filter.number"></el-input>
        </el-form-item>

        <el-form-item :label="$t('性别')" prop="gender">
          <el-select v-model="filter.gender">
            <el-option value="" :label="$t('全部')"></el-option>
            <el-option value="0" :label="$t('女')"></el-option>
            <el-option value="1" :label="$t('男')"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item :label="$t('年龄')" prop="age">
          <el-input v-model="filter.age"></el-input>
        </el-form-item>

        <el-form-item :label="$t('学历')" prop="education">
          <el-select v-model="filter.education">
            <el-option value="" :label="$t('全部')"></el-option>
            <el-option value="0" :label="$t('本科')"></el-option>
            <el-option value="1" :label="$t('硕士')"></el-option>
            <el-option value="2" :label="$t('博士')"></el-option>
            <el-option value="3" :label="$t('教授')"></el-option>
          </el-select>
        </el-form-item>

        <el-form-item :label="$t('手机号')" prop="mobile">
          <el-input v-model="filter.mobile"></el-input>
        </el-form-item>
      </el-form>
    </div>

    <div class="main">
      <el-table :data="data" stripe border>

        <el-table-column
                :label="$t('职工号')"
                prop="number"
                align="center"
        ></el-table-column>

        <el-table-column
          :label="$t('姓名')"
          prop="name"
          align="center"
        ></el-table-column>

        <el-table-column
          :label="$t('性别')"
          prop="gender"
          align="center"
        >
          <template slot-scope="scope">
            {{ scope.row.gender ? $t("男") : $t("女")}}
          </template>
        </el-table-column>

        <el-table-column
          :label="$t('年龄')"
          prop="age"
          align="center"
        >
        </el-table-column>

        <el-table-column
          :label="$t('民族')"
          prop="nation"
          align="center"
        >
        </el-table-column>

        <el-table-column
          :label="$t('手机号')"
          prop="mobile"
          align="center"
        >
        </el-table-column>

        <el-table-column
          :label="$t('婚姻状况')"
          prop="marital_status"
          align="center"
        >
          <template slot-scope="scope">
            {{ scope.row.marital_status ===null ? "" : marital_status_arr[scope.row.marital_status] }}
          </template>
        </el-table-column>

        <el-table-column
          :label="$t('最高学历')"
          prop="education"
          align="center"
        >
          <template slot-scope="scope">
            {{ scope.row.education ===null ? "" : educationArr[scope.row.education] }}
          </template>
        </el-table-column>

        <el-table-column
          :label="$t('毕业院校')"
          prop="graduate"
          align="center"
        >
        </el-table-column>

        <el-table-column
          :label="$t('家庭住址')"
          prop="address"
          align="center"
        >
        </el-table-column>
      </el-table>
    </div>

    <div class="footer">
      <el-pagination
              layout="total, sizes, prev, pager, next, jumper"
              :page-sizes= "[1,5,10,15,20]"
              :total="size"
              :page-size.sync="filter.pageSize"
              :current-page.sync="filter.currPage"
              background
              @size-change="pageChange"
              @current-change="pageChange"
      >
      </el-pagination>
    </div>
  </div>
</template>

<script>
  import searchApi from "@/api/search";

  export default {
    name: "TeachersInfo",
    data() {
      return {
        size: 0,
        filter: {
          pageSize: 10,
          currPage: 1,
          name: "",
          number: "",
          gender: "",
          age: "",
          education: "",
          mobile: ""
        },
        size: 0,
        data: [],
        marital_status_arr: [
          this.$t("未婚"),
          this.$t("已婚")
        ],
        educationArr: [
          this.$t("本科"),
          this.$t("硕士"),
          this.$t("博士"),
          this.$t("教授")
        ]
      };
    },
    created() {
      this.teachersInfoList();
    },
    methods: {
      teachersInfoList() {
        searchApi
          .teachersInfoList(this.filter)
          .then(data => {
            this.data = data.list;
            this.size = data.size;
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
      filterM() {
        this.filter.currPage = 1;
        this.teachersInfoList();
      },
      reset() {
        this.filter = {
          pageSize: 10,
          currPage: 1,
          name: "",
          number: "",
          gender: "",
          age: "",
          education: "",
        };
        this.teachersInfoList();
      },
      pageChange(val) {
        this.filter.currPage = val;
        this.teachersInfoList();
      }
    }
  };
</script>

<style scoped lang="scss">
  .teachers-info {
    height: 100%;
    display: flex;
    flex-direction: column;

    .el-input {
      width: 150px;
    }

    .el-select {
      width: 150px;
    }

    .search {
      .header {
        display: flex;
        background: whitesmoke;
        border: 1px solid #e3e3e3;
        border-bottom: 1px solid whitesmoke;

        .title {
          flex-grow: 1;
        }

        i {
          padding: 20px 5px 20px 20px;
        }

        span {
          padding: 20px 20px 20px 0;
        }

        .confirm,
        .reset {
          color: teal;
          cursor: pointer;
        }
      }

      .el-form {
        border: 1px solid #f3f3f3;
        padding: 20px;
      }
    }

    .main {
      flex-grow: 1;
      padding: 20px 0 60px;

      .el-button {
        margin: 5px;
      }
    }

    .footer {
      position: relative;

      .el-pagination {
        position: absolute;
        right: 0;
        bottom: 10px;
      }
    }
  }
</style>
