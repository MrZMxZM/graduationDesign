<template>
  <div class="course-info">
    <div class="search">
      <div class="header">
        <i class="el-icon-search"></i>
        <span class="title">{{ $t("筛选查询") }}</span>
        <span class="confirm" @click="filterM">{{ $t("筛选") }}</span>
        <span class="reset" @click="reset">{{ $t("重置") }}</span>
      </div>

      <el-form
              ref="filter"
              :model="filter"
              label-suffix=":"
              label-position="left"
      inline
      >

        <el-form-item :label="$t('部门编号')" prop="department_number">
          <el-input v-model="filter.department_number"></el-input>
        </el-form-item>

        <el-form-item :label="$t('部门名称')" prop="department_name">
          <el-input v-model="filter.department_name"></el-input>
        </el-form-item>
      </el-form>
    </div>

    <div class="main">
      <el-table :data="data" stripe border>

        <el-table-column
                :label="$t('部门编号')"
                prop="department_number"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('部门名称')"
                prop="department_name"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('教研项目')"
                prop="research_project"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('教研论文')"
                prop="research_paper"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('优秀课')"
                prop="perfect_course"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('学科竞赛')"
                prop="competition"
                align="center"
        >
        </el-table-column>

<!--        <el-table-column-->
<!--                :label="$t('立项时间')"-->
<!--                prop="address"-->
<!--                align="center"-->
<!--        >-->
<!--          {{ $t("2019-04-05")}}-->
<!--        </el-table-column>-->

<!--        <el-table-column-->
<!--                :label="$t('结项时间')"-->
<!--                prop="birthday"-->
<!--                align="center"-->
<!--        >-->
<!--          {{ $t("2019-05-01")}}-->
<!--        </el-table-column>-->
      </el-table>
    </div>

    <div class="footer">
      <el-pagination
              layout="total, sizes, prev, pager, next, jumper"
              :page-sizes= "[1,5,10,15,20]"
              :total="size"
              :page-size.sync="filter.pageSize"
              :current-page.sync="filter.currPage"
              background
              @size-change="pageChange"
              @current-change="pageChange"
      >
      </el-pagination>
    </div>
  </div>
</template>

<script>
  import searchApi from "@/api/search";

  export default {
    name: "CourseInfo",
    data() {
      return {
        size: 0,
        filter: {
          pageSize: 10,
          currPage: 1,
          department_number: "",
          department_name: "",
        },
        data: [],
      };
    },
    created() {
      this.departmentTotalList();
    },
    methods: {
      departmentTotalList() {
        searchApi
          .departmentTotalList(this.filter)
          .then(data => {
            this.data = data.list;
            this.size = data.size;
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
      filterM() {
        this.filter.currPage = 1;
        this.departmentTotalList();
      },
      reset() {
        this.filter = {
          pageSize: 10,
          currPage: 1,
          department_number: "",
          department_name: "",
        };
        this.departmentTotalList();
      },
      pageChange(val) {
        this.filter.currPage = val;
        this.departmentTotalList();
      }
    }
  };
</script>

<style scoped lang="scss">
  .course-info {
    height: 100%;
    display: flex;
    flex-direction: column;

    .el-input {
      width: 150px;
    }

    .el-select {
      width: 150px;
    }

    .search {
      .header {
        display: flex;
        background: whitesmoke;
        border: 1px solid #e3e3e3;
        border-bottom: 1px solid whitesmoke;

        .title {
          flex-grow: 1;
        }

        i {
          padding: 20px 5px 20px 20px;
        }

        span {
          padding: 20px 20px 20px 0;
        }

        .confirm,
        .reset {
          color: teal;
          cursor: pointer;
        }
      }

      .el-form {
        border: 1px solid #f3f3f3;
        padding: 20px;
      }
    }

    .main {
      flex-grow: 1;
      padding: 20px 0 60px;

      .el-button {
        margin: 5px;
      }
    }

    .footer {
      position: relative;

      .el-pagination {
        position: absolute;
        right: 0;
        bottom: 10px;
      }
    }
  }
</style>

