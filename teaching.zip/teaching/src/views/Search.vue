<template>
  <div class="search">
    <el-container>
      <el-aside width="200px">
        <el-menu :default-active="$route.path" router>
            <el-menu-item index="/search/studentInfo">
              <span slot="title">{{ $t("教师教研成果统计") }}</span>
            </el-menu-item>
            <el-menu-item index="/search/courseInfo">
              <span slot="title">{{ $t("部门教研成果统计") }}</span>
            </el-menu-item>
<!--            <el-menu-item v-if="right.includes('teacher')" index="/search/teachersInfo">-->
<!--              <span slot="title">{{ $t("教师信息") }}</span>-->
<!--            </el-menu-item>-->
<!--            <el-menu-item index="/search/resultsInfo">-->
<!--              <span slot="title">{{ $t("成绩信息") }}</span>-->
<!--            </el-menu-item>-->
        </el-menu>
      </el-aside>
      <el-main> <router-view></router-view> </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  name: "Search",
  data() {
    return {
      right: localStorage.getItem("right")
    }
  }
};
</script>

<style scoped lang="scss">
.search {
  height: 100%;

  .el-container {
    height: 100%;
  }
}
</style>
