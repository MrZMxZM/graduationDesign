<template>
  <div class="system">
    <el-container>
      <el-aside width="200px">
        <el-menu :default-active="$route.path" router>
          <el-menu-item index="/system/changePassword">
            <span slot="title">{{ $t("修改密码") }}</span>
          </el-menu-item>
          <el-menu-item v-if="right.includes('role')" index="/system/permissionsManage" >
            <span slot="title">{{ $t("权限管理") }}</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-main> <router-view></router-view> </el-main>
    </el-container>
  </div>
</template>

<script>
  export default {
    name: "System",
    data() {
      return {
        right: localStorage.getItem("right")
      }
    }
  };
</script>

<style scoped lang="scss">
  .system {
    height: 100%;

    .el-main {
      height: 1000px;
    }

    .el-container {
      height: 100%;
    }
  }
</style>
