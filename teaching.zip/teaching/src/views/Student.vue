<template>
  <div class="student">
    <el-container>
      <el-aside width="200px">
        <el-menu :default-active="$route.path" router>
          <el-menu-item index="/student/filesManage">
            <span slot="title">{{ $t("教研项目") }}</span>
          </el-menu-item>
          <el-menu-item index="/student/resultsManage">
            <span slot="title">{{ $t("教研论文") }}</span>
          </el-menu-item>
          <el-menu-item index="/student/perfectCourse">
            <span slot="title">{{ $t("优秀课") }}</span>
          </el-menu-item>
          <el-menu-item index="/student/competition">
            <span slot="title">{{ $t("学科竞赛") }}</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-main> <router-view></router-view> </el-main>
    </el-container>
  </div>
</template>

<script>
  export default {
    name: "Search"
  };
</script>

<style scoped lang="scss">
  .search {
    height: 100%;

    .el-container {
      height: 100%;
    }
  }
</style>
