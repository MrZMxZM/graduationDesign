<template>
    <div class="change-password">
        <div class="main">
            <el-form
                    ref="form"
                    :model="form"
                    :rules="rules"
                    label-suffix=":"
                    label-width="120px"
            >
                <el-form-item prop="oldPassword" :label="$t('原密码')">
                    <el-input v-model="form.oldPassword" type="password"></el-input>
                </el-form-item>

                <el-form-item prop="newPassword" :label="$t('新密码')">
                    <el-input v-model="form.newPassword" type="password"></el-input>
                </el-form-item>

                <el-form-item prop="confirmPassword" :label="$t('确认密码')">
                    <el-input v-model="form.confirmPassword" type="password"></el-input>
                </el-form-item>

                <el-form-item>
                    <el-button type="primary" :loading="loading" @click="submit">
                        {{ $t("修改密码") }}
                    </el-button>
                </el-form-item>
            </el-form>
        </div>
    </div>
</template>

<script>
  import systemApi from "@/api/system";

  export default {
    name: "ChangePassword",
    data() {
      let validateNewPassword = (rule, value, callback) => {
        if (value === "") {
          callback(new Error(this.$t("请输入")));
        } else {
          if (this.form.confirmPassword !== "") {
            this.$refs.form.validateField("confirmPassword");
          }
          callback();
        }
      };

      let validateConfirmPassword = (rule, value, callback) => {
        if (value === "") {
          callback(new Error(this.$t("请输入")));
        } else if (value !== this.form.newPassword) {
          callback(new Error(this.$t("与新密码不一致")));
        } else {
          callback();
        }
      };

      return {
        form: {
          oldPassword: "",
          newPassword: "",
          confirmPassword: ""
        },
        rules: {
          oldPassword: [
            {
              required: true,
              message: this.$t("请输入")
            },
            {
              pattern: /^[A-Za-z0-9]*$/,
              message: this.$t("请输入字母或数字")
            }
          ],
          newPassword: [
            {
              required: true,
              message: this.$t("请输入")
            },
            {
              pattern: /^[A-Za-z0-9]*$/,
              message: this.$t("请输入字母或数字")
            },
            {
              validator: validateNewPassword,
              trigger: "blur"
            }
          ],
          confirmPassword: [
            {
              required: true,
              message: this.$t("请输入")
            },
            {
              pattern: /^[A-Za-z0-9]*$/,
              message: this.$t("请输入字母或数字")
            },
            {
              validator: validateConfirmPassword,
              trigger: "blur"
            }
          ]
        },
        loading: false
      };
    },
    methods: {
      submit() {
        this.$refs.form.validate(valid => {
          if (valid) {
            this.loading = true;
            systemApi
              .passwordModify(this.form)
              .then(data => {
                this.$message.success(this.$t("密码修改成功, 请重新登录"));
                this.loading = false;
                this.$router.replace({ name: "login" });
              })
              .catch(e => {
                this.$message.error(this.$t(e));
                this.loading = false;
              });
          }
        });
      }
    }
  };
</script>

<style scoped lang="scss">
    .change-password {
        position: relative;

        .main {
            position: absolute;
            left: 25%;
            top: 150px;
            width: 500px;
            padding: 20px 40px;
            border-radius: 5px;
            border: 1px solid #e6e6e6;

            .el-form {
                .el-form-item {
                    margin-top: 20px;
                }

                .el-input {
                    width: 300px;
                }

                .el-button {
                    width: 300px;
                }
            }
        }
    }
</style>
