<template>
    <div class="permissions-manage">
        <div class="search">
            <div class="header">
                <i class="el-icon-search"></i>
                <span class="title">{{ $t("筛选查询") }}</span>
                <span class="confirm" @click="filterM">{{ $t("筛选") }}</span>
                <span class="reset" @click="reset">{{ $t("重置") }}</span>
                <span v-if="right.includes('save')" class="reset" @click="enteringDialogVisible = true">{{ $t("录入") }}</span>
            </div>

            <el-form
                    ref="filter"
                    :model="filter"
                    label-suffix=":"
                    label-position="left"
                    inline
            >
                <el-form-item :label="$t('账号')" prop="account">
                    <el-input v-model="filter.account"></el-input>
                </el-form-item>
            </el-form>
        </div>

        <div class="main">
            <el-table :data="data" stripe border>
                <el-table-column
                        :label="$t('编号')"
                        type="index"
                        width="50px"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('账号')"
                        prop="account"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('权限描述')"
                        prop="desc_role"
                        align="center"
                >
                    <template slot-scope="scope">
                        {{ scope.row.desc_role !== null ? desc_role_arr[scope.row.desc_role] : ""}}
                    </template>
                </el-table-column>

<!--                <el-table-column-->
<!--                        :label="$t('创建时间')"-->
<!--                        prop="gmt_create"-->
<!--                        align="center"-->
<!--                >-->
<!--                </el-table-column>-->

                <el-table-column
                        :label="$t('是否启用')"
                        prop="is_enable"
                        align="center"
                >
                    <template slot-scope="scope">
                        {{ scope.row.is_enable !== null ? is_enable_arr[scope.row.is_enable] : ""}}
                    </template>
                </el-table-column>

                <el-table-column
                        :label="$t('操作')"
                        align="center"
                >
                    <template slot-scope="scope">
                        <el-button v-if="right.includes('change')" type="text" size="small" @click="changeShow(scope.row.account)">{{ $t("修改") }}</el-button>
                        <el-button v-if="right.includes('delete')" type="text" size="small" @click="isDel(scope.row.account)">{{ $t("删除") }}</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>

        <div class="footer">
            <el-pagination
                    layout="total, sizes, prev, pager, next, jumper"
                    :page-sizes= "[1,5,10,15,20]"
                    :total="size"
                    :page-size.sync="filter.pageSize"
                    :current-page.sync="filter.currPage"
                    background
                    @size-change="pageChange"
                    @current-change="pageChange"
            >
            </el-pagination>
        </div>

        <el-dialog
            :title="$t('录入账号')"
            :visible.sync="enteringDialogVisible"
            center
            class="entering"
        >
            <el-form
                ref="enteringForm"
                :model="enteringForm"
                label-suffix=":"
                label-position="right"
                label-width="100px"
            >
                <el-form-item prop="account" :label="$t('账号')">
                    <el-input v-model="enteringForm.account"></el-input>
                </el-form-item>

                <el-form-item prop="password" :label="$t('密码')">
                    <el-input v-model="enteringForm.password"></el-input>
                </el-form-item>

                <el-form-item prop="type" :label="$t('类型')">
                    <el-select v-model="enteringForm.type">
                        <el-option value="1" :label="$t('教师')"></el-option>
                        <el-option value="2" :label="$t('管理员')"></el-option>
                    </el-select>
                </el-form-item>

                <el-form-item prop="desc_role" :label="$t('权限控制')">
                    <el-select v-model="enteringForm.desc_role">
                        <el-option value="1" :label="$t('教师权限')"></el-option>
                        <el-option value="2" :label="$t('管理员权限')"></el-option>
                    </el-select>
                </el-form-item>

                <el-form-item prop="is_enable" :label="$t('是否启用')">
                    <el-radio-group v-model="enteringForm.is_enable">
                        <el-radio :label="1">{{ $t("是") }}</el-radio>
                        <el-radio :label="0">{{ $t("否") }}</el-radio>
                    </el-radio-group>
                </el-form-item>
            </el-form>

            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="enteringLoading"
                        @click="enteringConfirm"
                >
                  {{ $t("确认录入") }}
                </el-button>

                <el-button @click="enteringDialogVisible = false">
                  {{ $t("取消") }}
                </el-button>
            </span>
        </el-dialog>

        <el-dialog
                :title="$t('修改权限')"
                :visible.sync="changeDialogVisible"
                class="change"
                center
                @close="clearDate"
        >
            <el-form
                    ref="changeForm"
                    :model="changeForm"
                    label-suffix=":"
                    label-position="right"
                    label-width="100px"
            >
                <el-form-item prop="account" :label="$t('账号')">
                    <el-input v-model="changeForm.account" :disabled="true"></el-input>
                </el-form-item>

<!--                <el-form-item prop="gmt_create" :label="$t('创建时间')">-->
<!--                    <el-input v-model="changeForm.gmt_create" :disabled="true"></el-input>-->
<!--                </el-form-item>-->

                <el-form-item prop="desc_role" :label="$t('权限控制')">
                    <el-select v-model="changeForm.desc_role">
                        <el-option :value="1" :label="$t('教师权限')"></el-option>
                        <el-option :value="2" :label="$t('管理员权限')"></el-option>
                    </el-select>
                </el-form-item>

                <el-form-item prop="is_enable" :label="$t('是否启用')">
                    <el-radio-group v-model="changeForm.is_enable">
                        <el-radio :label="1">{{ $t("是") }}</el-radio>
                        <el-radio :label="2">{{ $t("否") }}</el-radio>
                    </el-radio-group>
                </el-form-item>
            </el-form>

            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="changeLoading"
                        @click="changeConfirm"
                >
                  {{ $t("确认修改") }}
                </el-button>

                <el-button @click="changeDialogVisible = false">
                  {{ $t("取消") }}
                </el-button>
            </span>
        </el-dialog>

        <el-dialog
                :title="$t('删除')"
                :visible.sync="deleteDialogVisible"
                center
        >
            <div class="text-center"> {{ $t("确认删除此账号?") }}</div>

            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="deleteLoading"
                        @click="deleteConfirm"
                >
                  {{ $t("确认删除") }}
                </el-button>

                <el-button @click="deleteDialogVisible = false">
                  {{ $t("取消") }}
                </el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import systemApi from "@/api/system";
  export default {
    name: "PermissionsManage",
    data() {
      return {
        filter: {
          pageSize: 10,
          currPage: 1,
          account: ""
        },
        size: 0,
        data: [],
        enteringForm: {
          account: "",
          password: "",
          type: "",
          desc_role: "",
          is_enable: "",
        },
        changeForm: {
          account: "",
          passWord: "",
          desc_role: "",
          is_enable: "",
        },
        deleteAccount: "",
        desc_role_arr: [

          this.$t("教师权限"),
          this.$t("教师权限"),
          this.$t("管理员权限")
        ],
        is_enable_arr: [
          this.$t("否"),
          this.$t("是")
        ],
        right: localStorage.getItem("right"),
        enteringDialogVisible: false,
        changeDialogVisible: false,
        deleteDialogVisible: false,
        enteringLoading: false,
        changeLoading: false,
        deleteLoading: false,
      }
    },
    created() {
      this.permissionsManageList();
    },
    methods: {
      permissionsManageList() {
        systemApi
          .permissionsManageList(this.filter)
          .then(data => {
            this.data = data.list;
            this.size = data.size;
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
      enteringConfirm() {
        this.enteringLoading = true;
        systemApi
          .enteringConfirm(this.enteringForm)
          .then(data => {
            this.enteringLoading = false;
            this.enteringDialogVisible = false;
            this.$message.success(this.$t("录入成功"))
            this.permissionsManageList();
          })
          .catch(e => {
            this.enteringLoading = false;
            this.$message.error(this.$t(e));
          });
      },
      changeShow(account) {
        this.changeDialogVisible = true;
        systemApi
          .changeShow({account})
          .then(data => {
            this.changeForm = data;
          })
          .catch(e => {
            this.$message.error(this.$t(e))
          })
      },
      changeConfirm() {
        this.changeLoading = true;
        systemApi
          .changeConfirm(this.changeForm)
          .then(data => {
            this.changeLoading = false;
            this.changeDialogVisible = false;
            this.$message.success(this.$t("修改成功"))
            this.permissionsManageList();
          })
          .catch(e => {
            this.changeLoading = false;
            this.$message.error(this.$t(e));
          });
      },
      isDel(account) {
        this.deleteDialogVisible =true;
        this.deleteAccount = account;
      },
      deleteConfirm() {
        this.deleteLoading = true;
        systemApi
          .deleteConfirm({account: this.deleteAccount})
          .then(data => {
            this.deleteLoading = false;
            this.deleteDialogVisible = false;
            this.$message.success(this.$t("删除成功"))
            this.permissionsManageList();
          })
          .catch(e => {
            this.deleteLoading = false;
            this.$message.error(this.$t(e));
          });
      },
      clearDate() {
        this.changeForm = {
          account: "",
          passWord: "",
          desc_role: "",
          is_enable: "",
        }
      },
      filterM() {
        this.filter.currPage = 1;
        this.permissionsManageList();
      },
      reset() {
        this.filter = {
          pageSize: 10,
          currPage: 1,
          account: ""
        };
        this.permissionsManageList();
      },
      pageChange(val) {
        this.filter.currPage = val;
        this.permissionsManageList();
      }
    }
  };
</script>

<style scoped lang="scss">
    .permissions-manage {
        height: 100%;
        display: flex;
        flex-direction: column;

        .text-center {
            text-align: center;
        }

        .el-input {
            width: 150px;
        }

        .el-select {
            width: 150px;
        }

        .search {
            .header {
                display: flex;
                background: whitesmoke;
                border: 1px solid #e3e3e3;
                border-bottom: 1px solid whitesmoke;

                .title {
                    flex-grow: 1;
                }

                i {
                    padding: 20px 5px 20px 20px;
                }

                span {
                    padding: 20px 20px 20px 0;
                }

                .confirm,
                .reset {
                    color: teal;
                    cursor: pointer;
                }
            }

            .el-form {
                border: 1px solid #f3f3f3;
                padding: 20px;
            }
        }

        .main {
            flex-grow: 1;
            padding: 20px 0 60px;

            .el-button {
                margin: 5px;
            }
        }

        .footer {
            position: relative;

            .el-pagination {
                position: absolute;
                right: 0;
                bottom: 10px;
            }
        }

        .entering,
        .change {
            /deep/ {
                .el-dialog__body {
                    height: 150px;
                    .el-form {
                        .el-form-item {
                            float: left;
                            width: 300px;
                        }
                    }
                }
            }
        }
    }
</style>
