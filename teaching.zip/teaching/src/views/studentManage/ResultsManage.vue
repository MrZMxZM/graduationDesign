<template>
  <div class="results-manage">
    <div class="search">
      <div class="header">
        <i class="el-icon-search"></i>
        <span class="title">{{ $t("筛选查询") }}</span>
        <span class="confirm" @click="filterM">{{ $t("筛选") }}</span>
        <span class="reset" @click="reset">{{ $t("重置") }}</span>
        <span class="reset" @click="enteringDialogVisible = true">{{ $t("申请") }}</span>
      </div>

      <el-form
        ref="filter"
        :model="filter"
        label-suffix=":"
        label-position="left"
        inline
      >
        <el-form-item :label="$t('论文名称')" prop="paper_title">
          <el-input v-model="filter.paper_title"></el-input>
        </el-form-item>

        <el-form-item :label="$t('第一作者')" prop="first_author">
          <el-input v-model="filter.first_author"></el-input>
        </el-form-item>

        <el-form-item :label="$t('审核状态')" prop="status">
          <el-select v-model="filter.status">
            <el-option value="1" :label="$t('审核通过')"></el-option>
            <el-option value="0" :label="$t('未审核')"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
    </div>

    <div class="main">
      <el-table :data="data" stripe border>

        <el-table-column
                :label="$t('论文编号')"
                prop="paper_number"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('论文名称')"
                prop="paper_title"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('发表刊物')"
                prop="publications"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('刊物等级')"
                prop="level"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('检索')"
                prop="retrieve"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('第一作者')"
                prop="first_author"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('其他作者')"
                prop="other_authors"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('发表时间')"
                prop="published_time"
                align="center"
        >
        </el-table-column>

        <el-table-column
                :label="$t('审核状态')"
                prop="status"
                align="center"
        >
          <template slot-scope="scope">
            {{ statusArr[scope.row.status]}}
          </template>
        </el-table-column>

        <el-table-column
                :label="$t('操作')"
                align="center"
                v-if="right.includes('role')"
        >
          <template slot-scope="scope">
<!--            <el-button v-if="right.includes('score_save')" type="text" size="small" @click="enteringDetail(scope.row.stu_number, scope.row.test_name)">-->
<!--              {{ $t("录入成绩") }}-->
<!--            </el-button>-->

<!--            <el-button type="text" size="small" @click="detail(scope.row.stu_number, scope.row.test_name)">-->
<!--              {{ $t("查看详情") }}-->
<!--            </el-button>-->

            <el-button type="text" size="small" @click="auditShow(scope.row.paper_number)">
              {{ $t("审核") }}
            </el-button>

<!--            <el-button  v-if="right.includes('delete')" type="text" size="small" @click="isDel(scope.row.stu_number, scope.row.test_name)">-->
<!--              {{ $t("删除") }}-->
<!--            </el-button>-->
          </template>
        </el-table-column>
      </el-table>
    </div>

    <div class="footer">
      <el-pagination
              layout="total, sizes, prev, pager, next, jumper"
              :page-sizes= "[1,5,10,15,20]"
              :total="size"
              :page-size.sync="filter.pageSize"
              :current-page.sync="filter.currPage"
              background
              @size-change="pageChange"
              @current-change="pageChange"
      >
      </el-pagination>
    </div>

<!--    <results-manage-detail-->
<!--      v-if="isOpen"-->
<!--      @close="detail"-->
<!--      :studentNum="studentNum"-->
<!--      :testName="testName"-->
<!--    >-->
<!--    </results-manage-detail>-->

    <el-dialog
            :title="$t('申请教研论文')"
            :visible.sync="enteringDialogVisible"
            center
            class="enteringFiles"
            @close="clearData"
    >
      <el-form
              ref="form"
              :model="form"
              label-width="120px"
              label-position="right"
              label-suffix=":"
      >
        <el-form-item :label="$t('论文名称')" prop="paper_title">
          <el-input v-model="form.paper_title"></el-input>
        </el-form-item>

        <el-form-item :label="$t('发表刊物')" prop="publications">
          <el-input v-model="form.publications"></el-input>
        </el-form-item>

        <el-form-item :label="$t('刊物等级')" prop="level">
          <el-input v-model="form.level"></el-input>
        </el-form-item>

        <el-form-item :label="$t('检索')" prop="retrieve">
          <el-input v-model="form.retrieve"></el-input>
        </el-form-item>

        <el-form-item :label="$t('第一作者')" prop="first_author">
          <el-input v-model="form.first_author"></el-input>
        </el-form-item>

        <el-form-item :label="$t('其他作者')" prop="other_authors">
          <el-input v-model="form.other_authors"></el-input>
        </el-form-item>

        <el-form-item :label="$t('发表时间')" prop="published_time">
          <el-input v-model="form.published_time"></el-input>
        </el-form-item>

<!--        <el-form-item :label="$t('审核状态')" prop="status" v-if="right.includes('role')">-->
<!--          <el-radio-group v-model="form.status">-->
<!--            <el-radio label="1">{{$t('审核通过')}}</el-radio>-->
<!--            <el-radio label="0">{{$t('未审核')}}</el-radio>-->
<!--          </el-radio-group>-->
<!--        </el-form-item>-->
      </el-form>

      <span slot="footer">
        <el-button
                type="primary"
                :loading="enteringLoading"
                @click="applyConfirm"
        >
          {{ $t("确认申请") }}
        </el-button>

        <el-button @click="enteringDialogVisible = false;">
          {{ $t("取消") }}
        </el-button>
      </span>
    </el-dialog>

    <el-dialog
            :title="$t('审核')"
            :visible.sync="changeFilesDialogVisible"
            center
            class="changeFiles"
    >
      <el-form
              ref="changeFormForm"
              :model="changeFormForm"
              label-suffix=":"
              label-width="120px"
              label-position="right"
      >
        <el-form-item :label="$t('论文名称')" prop="paper_title">
          <el-input v-model="changeFormForm.paper_title" disabled></el-input>
        </el-form-item>

        <el-form-item :label="$t('发表刊物')" prop="publications">
          <el-input v-model="changeFormForm.publications" disabled></el-input>
        </el-form-item>

        <el-form-item :label="$t('刊物等级')" prop="level">
          <el-input v-model="changeFormForm.level" disabled></el-input>
        </el-form-item>

        <el-form-item :label="$t('检索')" prop="retrieve">
          <el-input v-model="changeFormForm.retrieve" disabled></el-input>
        </el-form-item>

        <el-form-item :label="$t('第一作者')" prop="first_author">
          <el-input v-model="changeFormForm.first_author" disabled></el-input>
        </el-form-item>

        <el-form-item :label="$t('其他作者')" prop="other_authors">
          <el-input v-model="changeFormForm.other_authors" disabled></el-input>
        </el-form-item>

        <el-form-item :label="$t('发表时间')" prop="published_time">
          <el-input v-model="changeFormForm.published_time" disabled></el-input>
        </el-form-item>

        <el-form-item :label="$t('审核状态')" prop="status">
          <el-radio-group v-model="changeFormForm.status">

            <el-radio label="1">{{$t('审核通过')}}</el-radio>
            <el-radio label="0">{{$t('未审核')}}</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>

      <span slot="footer">
        <el-button
                type="primary"
                :loading="changeLoading"
                @click="auditConfirm"
        >
          {{ $t("确认修改") }}
        </el-button>

        <el-button @click="changeFilesDialogVisible = false;">
          {{ $t("取消") }}
        </el-button>
      </span>
    </el-dialog>

<!--    <el-dialog-->
<!--            :title="$t('删除成绩')"-->
<!--            :visible.sync="deleteDialogVisible"-->
<!--            center-->
<!--            class="delete"-->
<!--            @close="clearData"-->
<!--    >-->
<!--      <div class="text-center">{{ $t("确认删除此条成绩?") }}</div>-->
<!--      <span slot="footer">-->
<!--        <el-button-->
<!--                type="primary"-->
<!--                :loading="deleteLoading"-->
<!--                @click="deleteConfirm"-->
<!--        >-->
<!--          {{ $t("确认删除") }}-->
<!--        </el-button>-->

<!--        <el-button @click="deleteDialogVisible = false;">-->
<!--          {{ $t("取消") }}-->
<!--        </el-button>-->
<!--        </span>-->
<!--    </el-dialog>-->
  </div>
</template>

<script>
   import studentApi from "@/api/student";
  // import searchApi from "@/api/search";
  // import ResultsManageDetail from "./ResultsManageDetail"

  export default {
    name: "ResultsManage",
    // components: {ResultsManageDetail},
    data() {
      return {
        filter: {
          pageSize: 10,
          currPage: 1,
          paper_title: "",
          first_author: "",
          status: "",
        },
        form: {
          paper_title: "",
          publications: "",
          level: "",
          retrieve: "",
          first_author: "",
          other_authors: "",
          published_time: "",
          status: "0",
        },
        // courseName: [],
        // changeForm: {
        //   test_name: "",
        //   stu_number: "",
        //   stu_name: "",
        //   stu_classes: "",
        //   age: "",
        //   sex: "",
        //   mobile: "",
        // },
        changeFormForm: {
          paper_title: "",
          publications: "",
          level: "",
          retrieve: "",
          first_author: "",
          other_authors: "",
          published_time: "",
          status: "",
        },
        statusArr:[
          this.$t("未审核"),
          this.$t("审核通过"),
        ],
        courseArr: [],
        size: 0,
        data: [],
        studentNum: "",
        testName: "",
        isOpen: false,
        hidden: true,
        right: localStorage.getItem("right"),
        changeFilesDialogVisible: false,
        deleteDialogVisible: false,
        enteringDialogVisible: false,
        deleteLoading: false,
        changeLoading: false,
        enteringLoading: false,
      };
    },
    created() {
      this.paperList();
    },
    methods: {
      // detail(numVal, testVal) {
      //   this.isOpen = !this.isOpen;
      //   this.studentNum = numVal;
      //   this.testName = testVal;
      // },
      paperList() {
        studentApi
          .paperList(this.filter)
          .then(data => {
            this.data = data.list;
            this.size = data.size;
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
     
      applyConfirm() {
        this.enteringLoading = true;
        studentApi
                .applyConfirm(this.form)
                .then(data => {
                  this.enteringLoading = false;
                  this.enteringDialogVisible = false;
                  this.$message.success(this.$t("申请成功"))
                  this.paperList();
                })
                .catch(e => {
                  this.enteringDialogVisible = false;
                  this.enteringLoading = false;
                  this.$message.error(e);
                })
      },
      auditShow(number) {
        this.changeFilesDialogVisible = true;
        studentApi
                .auditShow({paper_number: number})
                .then(data => {
                  this.changeFormForm = data;
                })
                .catch(e => {
                  this.$message.error(this.$t(e))
                })
      },
      auditConfirm() {
        this.changeLoading = true;
        studentApi
                .auditConfirm(this.changeFormForm)
                .then(data => {
                  this.changeLoading = false;
                  this.changeFilesDialogVisible = false;
                  this.$message.success(this.$t("审核成功"))
                  this.paperList();
                })
                .catch(e => {
                  this.changeFilesDialogVisible = false;
                  this.changeLoading = false;
                  this.$message.error(e);
                })
      },
      // isDel(stu_number, test_name) {
      //   this.deleteDialogVisible = true;
      //   this.studentNum = stu_number;
      //   this.testName = test_name;
      // },
      // deleteConfirm() {
      //   this.deleteLoading = true;
      //   studentApi
      //           .deleteConfirm({stu_number: this.studentNum, test_name: this.testName})
      //           .then(data => {
      //             this.deleteLoading = false;
      //             this.deleteDialogVisible = false;
      //             this.$message.success(this.$t("删除成功"))
      //             this.paperList();
      //           })
      //           .catch(e => {
      //             this.deleteDialogVisible = false;
      //             this.deleteLoading = false;
      //             this.$message.error(e);
      //           })
      // },
      clearData() {
        this.form = {
          paper_title: "",
                  publications: "",
                  level: "",
                  retrieve: "",
                  first_author: "",
                  other_authors: "",
                  published_time: "",
                  status: "0",
        }
      },
      filterM() {
        this.filter.currPage = 1;
        this.paperList();
      },
      reset() {
        this.filter = {
          pageSize: 10,
          currPage: 1,
          paper_title: "",
          first_author: "",
          status: "",
        };
        this.paperList();
      },
      pageChange(val) {
        this.filter.currPage = val;
        this.paperList();
      }
    }
  };
</script>

<style scoped lang="scss">
  .results-manage{
    height: 100%;
    display: flex;
    flex-direction: column;

    .text-center {
      text-align: center;
    }

    .el-input {
      width: 150px;
    }

    .el-select {
      width: 150px;
    }

    .search {
      .header {
        display: flex;
        background: whitesmoke;
        border: 1px solid #e3e3e3;
        border-bottom: 1px solid whitesmoke;

        .title {
          flex-grow: 1;
        }

        i {
          padding: 20px 5px 20px 20px;
        }

        span {
          padding: 20px 20px 20px 0;
        }

        .confirm,
        .reset {
          color: teal;
          cursor: pointer;
        }
      }

      .el-form {
        border: 1px solid #f3f3f3;
        padding: 20px;
      }
    }

    .main {
      flex-grow: 1;
      padding: 20px 0 60px;

      .el-button {
        margin: 5px;
      }
    }

    .footer {
      position: relative;

      .el-pagination {
        position: absolute;
        right: 0;
        bottom: 10px;
      }
    }

    .enteringFiles,
    .changeFiles {

      /deep/ {

        .el-dialog__body {
          height: 250px;

          .el-form {

            .el-form-item {
              float: left;
              width: 300px;
            }
          }
        }

        .el-dialog__footer{
        }
      }
    }
  }
</style>
