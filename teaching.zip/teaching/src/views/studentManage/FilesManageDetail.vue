<template>
  <div class="files-manage-detail shadow">
    <div class="close"><i class="el-icon-close" @click="close"></i></div>
    <div class="main" ref="main">
      <div class="bill-detail">
        <div class="header">
          <div>
            {{ $t("档案详情") }}
          </div>
        </div>

        <div class="flex-table">
          <div
            v-for="(item, index) in bidDetail"
            :key="index"
          >
            <div class="label">
              <div class="center-vertical">{{ item.label }}</div>
            </div>
            <div class="value">
              <div class="center-vertical">{{ item.value }}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import studentApi from "@/api/student"

  export default {
    name: "FilesManageDetail",
    props: ["number"],
    data() {
      return {
        data: {}
      };
    },
    computed: {
      bidDetail() {
        return [
          {
            label: this.$t("学号"),
            value: this.data.number
          },
          {
            label: this.$t("姓名"),
            value: this.data.name
          },
          {
            label: this.$t("年龄"),
            value: this.data.age
          },
          {
            label: this.$t("性别"),
            value: this.data.gender && this.data.gender ? this.$t("男") : this.$t("女")
          },
          {
            label: this.$t("班级"),
            value: this.data.classes
          },
          {
            label: this.$t("寝室"),
            value: this.data.dormitory
          },
          {
            label: this.$t("电话"),
            value: this.data.mobile
          },
          {
            label: this.$t("国籍"),
            value: this.data.citizenship
          },
          {
            label: this.$t("民族"),
            value: this.data.nation
          },
          {
            label: this.$t("状态"),
            value: this.data.status && this.data.status ? this.$t("在校") : this.$t("休学")
          },
          {
            label: this.$t("出生日期"),
            value: this.data.birthday
          },
          {
            label: this.$t("生源类别"),
            value: this.data.stu_type && this.data.stu_type ? this.$t("提前批") : this.$t("统招")
          },
          {
            label: this.$t("政治面貌"),
            value: this.data.politics_status
          },
          {
            label: this.$t("父亲电话"),
            value: this.data.father_mobile
          },
          {
            label: this.$t("母亲电话"),
            value: this.data.mother_mobile
          },
          {
            label: this.$t("家庭住址"),
            value: this.data.address
          },
          {
            label: this.$t("入学时间"),
            value: this.data.enrol_time
          },
          {
            label: this.$t("毕业去向"),
            value: this.data.after_graduation
          }
        ];
      },
    },
    created() {
      this.changeConfirmShow();
    },
    methods: {
      close() {
        this.$emit("close")
      },
      changeConfirmShow() {
        studentApi
          .changeConfirmShow({number: this.number})
          .then(data => {
            this.data = data;
          })
          .catch(e => {
            this.$message.error(this.$t(e))
          })
      }
    }
  };
</script>

<style scoped lang="scss">
  .files-manage-detail {
    background: white;
    position: fixed;
    top: 135px;
    right: 20px;
    bottom: 20px;
    left: 300px;
    z-index: 99;

    .close {
      text-align: right;

      i {
        font-size: 1.2rem;
        padding: 10px;
        cursor: pointer;
      }
    }

    .main {
      height: calc(100% - 40px);
      overflow: auto;

      .bill-detail {
        padding: 20px;

        .header {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          margin-bottom: 20px;

          .label {
            color: #303030;
          }

          .bid {
            font-size: 1.4rem;
            margin-left: 8px;
          }

          .status {
            font-size: 1.4rem;
            margin-left: 8px;
          }
        }
      }

      .flex-table {
        display: flex;
        flex-wrap: wrap;

        > div {
          display: flex;
          width: calc(25% - 2px);
          min-width: 240px;
          border: 1px solid #ababab;
          margin: 0 -1px -1px 0;
          text-align: center;
          word-break: break-all;

          .label {
            width: 40%;
            height: 60px;
            background: #f4f4f4;
            border-right: 1px solid #ababab;
          }

          .value {
            width: 60%;
            height: 60px;
          }
        }
      }

      .center-vertical {
        position: relative;
        top: 50%;
        transform: translateY(-50%);
      }
    }

    .el-tabs {
      margin: 20px;
    }
  }
</style>
