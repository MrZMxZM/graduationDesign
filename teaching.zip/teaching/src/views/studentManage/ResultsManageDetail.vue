<template>
  <div class="results-manage-detail shadow">
    <div class="close"><i class="el-icon-close" @click="close"></i></div>
    <div class="main" ref="main">
      <div class="bill-detail">
        <div class="header">
          <div>
            {{ $t("成绩详情") }}
          </div>
        </div>

        <div class="flex-table">

          <div>
            <div class="label">
              <div class="center-vertical">{{ $t("姓名") }}</div>
            </div>

            <div class="value">
              <div class="center-vertical">{{ data.stu_name}}</div>
            </div>
          </div>

          <div>
            <div class="label">
              <div class="center-vertical">{{ $t("学号") }}</div>
            </div>

            <div class="value">
              <div class="center-vertical">{{ data.stu_number}}</div>
            </div>
          </div>

          <div>
            <div class="label">
              <div class="center-vertical">{{ $t("班级") }}</div>
            </div>

            <div class="value">
              <div class="center-vertical">{{ data.stu_classes}}</div>
            </div>
          </div>
          <div
                  v-for="(item, index) in data.cou_name_gender"
                  :key="index"
          >
            <div class="label">
              <div class="center-vertical">{{ item.cou_name }}</div>
            </div>
            <div class="value">
              <div class="center-vertical">{{ item.grade }}</div>
            </div>
          </div>

          <div>
            <div class="label">
              <div class="center-vertical">{{ $t("平均分") }}</div>
            </div>

            <div class="value">
              <div class="center-vertical">{{ data.average_score}}</div>
            </div>
          </div>

          <div>
            <div class="label">
              <div class="center-vertical">{{ $t("总分") }}</div>
            </div>

            <div class="value">
              <div class="center-vertical">{{ data.total}}</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import searchApi from "@/api/search";

  export default {
    name: "ResultsManageDetail",
    props: ["studentNum", "testName"],
    data() {
      return {
        data: {}
      }
    },
    created() {
      this.resultsInfoDetail();
    },
    methods: {
      close() {
        this.$emit("close")
      },
      resultsInfoDetail() {
        searchApi
          .resultsInfoDetail({stu_number:this.studentNum, test_name: this.testName})
          .then(data => {
            this.data = data;
          })
          .catch(e => {
            this.$message.error(e);
          })
      },
    }
  };
</script>

<style scoped lang="scss">
  .results-manage-detail  {
    background: white;
    position: fixed;
    top: 135px;
    right: 20px;
    bottom: 20px;
    left: 300px;
    z-index: 99;

    .close {
      text-align: right;

      i {
        font-size: 1.2rem;
        padding: 10px;
        cursor: pointer;
      }
    }

    .main {
      height: calc(100% - 40px);
      overflow: auto;

      .bill-detail {
        padding: 20px;

        .header {
          display: flex;
          align-items: flex-end;
          justify-content: space-between;
          margin-bottom: 20px;

          .label {
            color: #303030;
          }

          .bid {
            font-size: 1.4rem;
            margin-left: 8px;
          }

          .status {
            font-size: 1.4rem;
            margin-left: 8px;
          }
        }
      }

      .flex-table {
        display: flex;
        flex-wrap: wrap;

        > div {
          display: flex;
          width: calc(50% - 2px);
          min-width: 240px;
          border: 1px solid #ababab;
          margin: 0 -1px -1px 0;
          text-align: center;
          word-break: break-all;

          .label {
            width: 100%;
            height: 60px;
            background: #f4f4f4;
            border-right: 1px solid #ababab;
          }

          .value {
            width: 60%;
            height: 60px;
          }
        }
      }

      .center-vertical {
        position: relative;
        top: 50%;
        transform: translateY(-50%);
      }
    }

    .el-tabs {
      margin: 20px;
    }
  }
</style>
