<template>
    <div class="files-manage">
        <div class="search">
            <div class="header">
                <i class="el-icon-search"></i>
                <span class="title">{{ $t("筛选查询") }}</span>
                <span class="confirm" @click="filterM">{{ $t("筛选") }}</span>
                <span class="reset" @click="reset">{{ $t("重置") }}</span>
                <span class="reset" @click="enteringDialogVisible = true">{{ $t("申请") }}</span>
            </div>

            <el-form
                    ref="filter"
                    :model="filter"
                    label-suffix=":"
                    label-position="left"
                    inline
            >
               
                <el-form-item :label="$t('课题编号')" prop="subject_number">
                    <el-input v-model="filter.subject_number"></el-input>
                </el-form-item>

                <el-form-item :label="$t('课题名称')" prop="subject_name">
                    <el-input v-model="filter.subject_name"></el-input>
                </el-form-item>

                <el-form-item :label="$t('级别')" prop="level">
                    <el-input v-model="filter.level"></el-input>
                </el-form-item>

                <el-form-item :label="$t('带头人')" prop="leader">
                    <el-input v-model="filter.leader"></el-input>
                </el-form-item>

                <el-form-item :label="$t('审核状态')" prop="status">
                    <el-select v-model="filter.status">
                        <el-option value="1" :label="$t('审核通过')"></el-option>
                        <el-option value="0" :label="$t('未审核')"></el-option>
                    </el-select>
                </el-form-item>
            </el-form>
        </div>

        <div class="main">
            <el-table :data="data" stripe border>

                <el-table-column
                        :label="$t('课题编号')"
                        prop="subject_number"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('课题名称')"
                        prop="subject_name"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('级别')"
                        prop="level"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('带头人')"
                        prop="leader"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('其他成员')"
                        prop="members"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('批准经费')"
                        prop="funding"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('完成单位')"
                        prop="complete_unit"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('立项时间')"
                        prop="start_time"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('结项时间')"
                        prop="end_time"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('审核状态')"
                        prop="status"
                        align="center"
                >
                    <template slot-scope="scope">
                        {{ statusArr[scope.row.status]}}
                    </template>
                </el-table-column>

                <el-table-column
                        :label="$t('操作')"
                        align="center"
                        width="150px"
                        v-if="right.includes('role')"
                >
                    <template slot-scope="scope">
<!--                        <el-button type="text" size="small" @click="detail(scope.row.number)">-->
<!--                            {{ $t("查看详情") }}-->
<!--                        </el-button>-->

                        <el-button type="text" size="small" @click="changeConfirmShow(scope.row.subject_number)">
                            {{ $t("审核") }}
                        </el-button>

<!--                        <el-button v-if="right.includes('delete')" type="text" size="small" @click="cancel(scope.row.number)">-->
<!--                            {{ $t("删除") }}-->
<!--                        </el-button>-->
                    </template>
                </el-table-column>
            </el-table>
        </div>

<!--        <files-manage-detail-->
<!--                v-if="isOpen"-->
<!--                @click="detail"-->
<!--                @close="detail"-->
<!--                :number="number"-->
<!--        >-->
<!--        </files-manage-detail>-->


        <el-dialog
                :title="$t('申请教研项目')"
                :visible.sync="enteringDialogVisible"
                center
                class="enteringResult"
                @close="clearData"
        >
            <el-form
                    ref="form"
                    :model="form"
                    label-width="100px"
                    label-suffix=":"
            >

<!--                <el-form-item :label="$t('课题编号')" prop="subject_number">-->
<!--                    <el-input v-model="form.subject_number"></el-input>-->
<!--                </el-form-item>-->

                <el-form-item :label="$t('课题名称')" prop="subject_name">
                    <el-input v-model="form.subject_name"></el-input>
                </el-form-item>

                <el-form-item :label="$t('级别')" prop="level">
                    <el-input v-model="form.level"></el-input>
                </el-form-item>

                <el-form-item :label="$t('带头人')" prop="leader">
                    <el-input v-model="form.leader"></el-input>
                </el-form-item>

                <el-form-item :label="$t('其他成员')" prop="members">
                    <el-input v-model="form.members"></el-input>
                </el-form-item>

                <el-form-item :label="$t('批准经费')" prop="funding">
                    <el-input v-model="form.funding"></el-input>
                </el-form-item>

                <el-form-item :label="$t('完成单位')" prop="complete_unit">
                    <el-input v-model="form.complete_unit"></el-input>
                </el-form-item>

                <el-form-item :label="$t('立项时间')" prop="start_time">
                    <el-input v-model="form.start_time"></el-input>
                </el-form-item>

                <el-form-item :label="$t('结项时间')" prop="name">
                    <el-input v-model="form.end_time"></el-input>
                </el-form-item>

<!--                <el-form-item :label="$t('审核状态')" prop="status" v-if="right.includes('role')">-->
<!--                    <el-radio-group v-model="form.status" >-->
<!--                        <el-radio label="1">{{$t('审核通过')}}</el-radio>-->
<!--                        <el-radio label="0">{{$t('未审核')}}</el-radio>-->
<!--                    </el-radio-group>-->
<!--                </el-form-item>-->
            </el-form>

            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="enteringLoading"
                        @click="subjectApply"
                >
                  {{ $t("确认申请") }}
                </el-button>

                <el-button @click="enteringDialogVisible = false;">
                  {{ $t("取消") }}
                </el-button>
            </span>
        </el-dialog>

        <el-dialog
                :title="$t('审核')"
                :visible.sync="changeDialogVisible"
                center
                class="changeResult"
        >
            <el-form
                    ref="changeForm"
                    :model="changeForm"
                    label-width="100px"
                    label-suffix=":"
            >

                <el-form-item :label="$t('课题编号')" prop="subject_number">
                    <el-input v-model="changeForm.subject_number" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('课题名称')" prop="subject_name">
                    <el-input v-model="changeForm.subject_name" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('级别')" prop="level">
                    <el-input v-model="changeForm.level" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('带头人')" prop="leader">
                    <el-input v-model="changeForm.leader" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('其他成员')" prop="members">
                    <el-input v-model="changeForm.members" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('批准经费')" prop="funding">
                    <el-input v-model="changeForm.funding" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('完成单位')" prop="complete_unit">
                    <el-input v-model="changeForm.complete_unit" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('立项时间')" prop="start_time">
                    <el-input v-model="changeForm.start_time" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('结项时间')" prop="end_time">
                    <el-input v-model="changeForm.end_time" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('审核状态')" prop="status">
                    <el-radio-group v-model="changeForm.status">
                        <el-radio label="1">{{$t('审核通过')}}</el-radio>
                        <el-radio label="0">{{$t('未审核')}}</el-radio>
                    </el-radio-group>
                </el-form-item>
            </el-form>

            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="changeLoading"
                        @click="subjectAudit"
                >
                  {{ $t("确认") }}
                </el-button>

                <el-button @click="changeDialogVisible = false">
                  {{ $t("取消") }}
                </el-button>
            </span>
        </el-dialog>

<!--        <el-dialog-->
<!--                :title="$t('删除档案')"-->
<!--                :visible.sync="deleteDialogVisible"-->
<!--                center-->
<!--        >-->
<!--            <div class="text-center">{{ $t("确认删除此条档案?") }}</div>-->
<!--            <span slot="footer">-->
<!--        <el-button-->
<!--                type="primary"-->
<!--                :loading="deleteLoading"-->
<!--                @click="isCancel"-->
<!--        >-->
<!--          {{ $t("确认删除") }}-->
<!--        </el-button>-->

<!--        <el-button @click="deleteDialogVisible = false">-->
<!--          {{ $t("取消") }}-->
<!--        </el-button>-->
<!--        </span>-->
<!--        </el-dialog>-->

        <div class="footer">
            <el-pagination
                    layout="total, sizes, prev, pager, next, jumper"
                    :page-sizes="[1,5,10,15,20]"
                    :total="size"
                    :page-size.sync="filter.pageSize"
                    :current-page.sync="filter.currPage"
                    background
                    @size-change="pageChange"
                    @current-change="pageChange"
            >
            </el-pagination>
        </div>
    </div>
</template>

<script>
  import studentApi from "@/api/student"
  import FilesManageDetail from "./FilesManageDetail";

  export default {
    name: "FilesManage",
    components: { FilesManageDetail },
    data() {
      return {
        filter: { 
          pageSize: 10,
          currPage: 1,
          subject_number: "",
          subject_name: "",
          level: "",
          leader: "",
          status: "",
        },
        form: {
          // subject_number: "",
          subject_name: "",
          level: "",
          leader: "",
          members: "",
          funding: "",
          complete_unit: "",
          start_time: "",
          end_time: "",
          status: "0",
        },
        changeForm: {
          subject_number: "",
          subject_name: "",
          level: "",
          leader: "",
          members: "",
          funding: "",
          complete_unit: "",
          start_time: "",
          end_time: "",
          status: "",
        },
        statusArr:[
          this.$t("未审核"),
          this.$t("审核通过"),
        ],
        changeData: [],
        size: 0,
        data: [],
        isOpen: false,
        number: "",
        scopeNumber: "",
        right: localStorage.getItem("right"),
        enteringDialogVisible: false,
        changeDialogVisible: false,
        deleteDialogVisible: false,
        enteringLoading: false,
        changeLoading: false,
        deleteLoading: false
      };
    },
    created() {
      this.subjectList();
    },
    methods: {
      // detail(val) {
      //   this.isOpen = !this.isOpen;
      //   this.number = val;
      // },
      subjectList() {
        studentApi
          .subjectList(this.filter)
          .then(data => {
            this.data = data.list;
            this.size = data.size;
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
      subjectApply() {
        this.enteringLoading = true;
        studentApi
          .subjectApply(this.form)
          .then(data => {
            this.enteringLoading = false;
            this.enteringDialogVisible = false;
            this.$message.success(this.$t("申请成功"));
            this.subjectList();
          })
          .catch(e => {
            this.enteringLoading = false;
            this.$message.error(this.$t(e));
          });
      },
      changeConfirmShow(number) {
        this.changeDialogVisible = true;
        studentApi
          .subjectAuditShow({subject_number: number})
          .then(data => {
           this.changeForm = data;
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
      subjectAudit() {
        this.changeLoading = true;
        studentApi
          .subjectAudit(this.changeForm)
          .then(data => {
            this.changeLoading = false;
            this.changeDialogVisible = false;
            this.$message.success(this.$t("审核成功"));
            this.subjectList();
          })
          .catch(e => {
            this.changeLoading = false;
            this.$message.error(this.$t(e));
          });
      },
      clearData() {
        this.form ={
            // subject_number: "",
            subject_name: "",
            level: "",
            leader: "",
            members: "",
            funding: "",
            complete_unit: "",
            start_time: "",
            end_time: "",
            status: "0",
        }
      },
      cancel(val) {
        this.deleteDialogVisible = true;
        this.scopeNumber = val;
      },
      // isCancel() {
      //   this.deleteLoading = true;
      //   studentApi
      //     .isCancel({number: this.scopeNumber})
      //     .then(data => {
      //       this.deleteLoading = false;
      //       this.deleteDialogVisible = false;
      //       this.$message.success(this.$t("删除成功"));
      //       this.subjectList();
      //     })
      //     .catch(e => {
      //       this.deleteLoading = false;
      //       this.$message.error(this.$t(e));
      //     });
      // },
      filterM() {
        this.filter.currPage = 1;
        this.subjectList();
      },
      reset() {
        this.filter = {
          pageSize: 10,
          currPage: 1,
          subject_number: "",
          subject_name: "",
          level: "",
          leader: "",
          status: "",
        };
        this.subjectList();
      },
      pageChange(val) {
        this.filter.currPage = val;
        this.subjectList();
      }
    }
  };
</script>

<style scoped lang="scss">
    .files-manage {
        height: 100%;
        display: flex;
        flex-direction: column;
    
        .text-center {
            text-align: center;
        }
    
        .el-input {
            width: 150px;
        }
    
        .el-select {
            width: 150px;
        }
    
        .search {
            .header {
                display: flex;
                background: whitesmoke;
                border: 1px solid #e3e3e3;
                border-bottom: 1px solid whitesmoke;
    
                .title {
                    flex-grow: 1;
                }
    
                i {
                    padding: 20px 5px 20px 20px;
                }
    
                span {
                    padding: 20px 20px 20px 0;
                }
    
                .confirm,
                .reset {
                    color: teal;
                    cursor: pointer;
                }
            }
    
            .el-form {
                border: 1px solid #f3f3f3;
                padding: 20px;
            }
        }
    
        .main {
            flex-grow: 1;
            padding: 20px 0 60px;
    
            .el-button {
                margin: 5px;
            }
        }
    
        .footer {
            position: relative;
    
            .el-pagination {
                position: absolute;
                right: 0;
                bottom: 10px;
            }
        }
    
        .enteringResult,
        .changeResult {
    
            /deep/ {
    
                .el-dialog__body {
                    height: 280px;
    
                    .el-form {
                        padding-left: 40px;
    
                        .el-form-item {
                            float: left;
                            width: 300px;
                        }
                    }
                }
            }
        }
    }
</style>
