<template>
    <div class="perfect-course">
        <div class="search">
            <div class="header">
                <i class="el-icon-search"></i>
                <span class="title">{{ $t("筛选查询") }}</span>
                <span class="confirm" @click="filterM">{{ $t("筛选") }}</span>
                <span class="reset" @click="reset">{{ $t("重置") }}</span>
                <span class="reset" @click="enteringDialogVisible = true">{{ $t("申请") }}</span>
            </div>

            <el-form
                    ref="filter"
                    :model="filter"
                    label-suffix=":"
                    label-position="left"
                    inline
            >

                <el-form-item :label="$t('课程名称')" prop="class_name">
                    <el-input v-model="filter.class_name"></el-input>
                </el-form-item>

                <el-form-item :label="$t('级别')" prop="level">
                    <el-input v-model="filter.level"></el-input>
                </el-form-item>

                <el-form-item :label="$t('带头人')" prop="leader">
                    <el-input v-model="filter.leader"></el-input>
                </el-form-item>

                <el-form-item :label="$t('审核状态')" prop="status">
                    <el-select v-model="filter.status">
                        <el-option value="1" :label="$t('审核通过')"></el-option>
                        <el-option value="0" :label="$t('未审核')"></el-option>
                    </el-select>
                </el-form-item>
            </el-form>
        </div>

        <div class="main">
            <el-table :data="data" stripe border>

                <el-table-column
                        :label="$t('课程编号')"
                        prop="perfect_course_number"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('课程名称')"
                        prop="class_name"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('级别')"
                        prop="level"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('带头人')"
                        prop="leader"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('其他成员')"
                        prop="members"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('批准时间')"
                        prop="approval_time"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('评定单位')"
                        prop="evaluate_unit"
                        align="center"
                >
                </el-table-column>

                <el-table-column
                        :label="$t('审核状态')"
                        prop="status"
                        align="center"
                >
                    <template slot-scope="scope">
                        {{ statusArr[scope.row.status]}}
                    </template>
                </el-table-column>

                <el-table-column
                        :label="$t('操作')"
                        align="center"
                        width="150px"
                        v-if="right.includes('role')"
                >
                    <template slot-scope="scope">
                        <!--                        <el-button type="text" size="small" @click="detail(scope.row.number)">-->
                        <!--                            {{ $t("查看详情") }}-->
                        <!--                        </el-button>-->

                        <el-button type="text" size="small" @click="courseAuditShow(scope.row.perfect_course_number)">
                            {{ $t("审核") }}
                        </el-button>

                        <!--                        <el-button v-if="right.includes('delete')" type="text" size="small" @click="cancel(scope.row.number)">-->
                        <!--                            {{ $t("删除") }}-->
                        <!--                        </el-button>-->
                    </template>
                </el-table-column>
            </el-table>
        </div>

        <files-manage-detail
                v-if="isOpen"
                @click="detail"
                @close="detail"
                :number="number"
        >
        </files-manage-detail>


        <el-dialog
                :title="$t('申请优秀课')"
                :visible.sync="enteringDialogVisible"
                center
                class="enteringResult"
                @close="clearData"
        >
            <el-form
                    ref="form"
                    :model="form"
                    label-width="100px"
                    label-suffix=":"
            >

                <el-form-item :label="$t('课题名称')" prop="class_name">
                    <el-input v-model="form.class_name"></el-input>
                </el-form-item>

                <el-form-item :label="$t('级别')" prop="level">
                    <el-input v-model="form.level"></el-input>
                </el-form-item>

                <el-form-item :label="$t('带头人')" prop="leader">
                    <el-input v-model="form.leader"></el-input>
                </el-form-item>

                <el-form-item :label="$t('其他成员')" prop="members">
                    <el-input v-model="form.members"></el-input>
                </el-form-item>

                <el-form-item :label="$t('批准时间')" prop="approval_time">
                    <el-input v-model="form.approval_time"></el-input>
                </el-form-item>

                <el-form-item :label="$t('评定单位')" prop="evaluate_unit">
                    <el-input v-model="form.evaluate_unit"></el-input>
                </el-form-item>

<!--                <el-form-item :label="$t('审核状态')" prop="status" v-if="right.includes('role')">-->
<!--                    <el-radio-group v-model="form.status">-->
<!--                        <el-radio label="1">{{$t('审核通过')}}</el-radio>-->
<!--                        <el-radio label="0">{{$t('未审核')}}</el-radio>-->
<!--                    </el-radio-group>-->
<!--                </el-form-item>-->
            </el-form>

            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="enteringLoading"
                        @click="courseApplyConfirm"
                >
                  {{ $t("确认申请") }}
                </el-button>

                <el-button @click="enteringDialogVisible = false;">
                  {{ $t("取消") }}
                </el-button>
            </span>
        </el-dialog>

        <el-dialog
                :title="$t('审核')"
                :visible.sync="changeDialogVisible"
                center
                class="changeResult"
        >
            <el-form
                    ref="changeForm"
                    :model="changeForm"
                    label-width="100px"
                    label-suffix=":"
            >

                <el-form-item :label="$t('课题名称')" prop="class_name">
                    <el-input v-model="changeForm.class_name" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('级别')" prop="level">
                    <el-input v-model="changeForm.level" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('带头人')" prop="leader">
                    <el-input v-model="changeForm.leader" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('其他成员')" prop="members">
                    <el-input v-model="changeForm.members" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('批准时间')" prop="approval_time">
                    <el-input v-model="changeForm.approval_time" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('评定单位')" prop="evaluate_unit">
                    <el-input v-model="changeForm.evaluate_unit" disabled></el-input>
                </el-form-item>

                <el-form-item :label="$t('审核状态')" prop="status">
                    <el-radio-group v-model="changeForm.status">
                        <el-radio label="1">{{$t('审核通过')}}</el-radio>
                        <el-radio label="0">{{$t('未审核')}}</el-radio>
                    </el-radio-group>
                </el-form-item>
            </el-form>

            <span slot="footer">
                <el-button
                        type="primary"
                        :loading="changeLoading"
                        @click="courseAuditConfirm"
                >
                  {{ $t("确认修改") }}
                </el-button>

                <el-button @click="changeDialogVisible = false">
                  {{ $t("取消") }}
                </el-button>
            </span>
        </el-dialog>

        <!--        <el-dialog-->
        <!--                :title="$t('删除档案')"-->
        <!--                :visible.sync="deleteDialogVisible"-->
        <!--                center-->
        <!--        >-->
        <!--            <div class="text-center">{{ $t("确认删除此条档案?") }}</div>-->
        <!--            <span slot="footer">-->
        <!--        <el-button-->
        <!--                type="primary"-->
        <!--                :loading="deleteLoading"-->
        <!--                @click="isCancel"-->
        <!--        >-->
        <!--          {{ $t("确认删除") }}-->
        <!--        </el-button>-->

        <!--        <el-button @click="deleteDialogVisible = false">-->
        <!--          {{ $t("取消") }}-->
        <!--        </el-button>-->
        <!--        </span>-->
        <!--        </el-dialog>-->

        <div class="footer">
            <el-pagination
                    layout="total, sizes, prev, pager, next, jumper"
                    :page-sizes="[1,5,10,15,20]"
                    :total="size"
                    :page-size.sync="filter.pageSize"
                    :current-page.sync="filter.currPage"
                    background
                    @size-change="pageChange"
                    @current-change="pageChange"
            >
            </el-pagination>
        </div>
    </div>
</template>

<script>
  import studentApi from "@/api/student"
  import FilesManageDetail from "./FilesManageDetail";

  export default {
    name: "PerfectCourse",
    components: { FilesManageDetail },
    data() {
      return {
        filter: {
          pageSize: 10,
          currPage: 1,
          class_name: "",
          level: "",
          leader: "",
          status: "",
        },
        form: {
          class_name: "",
          level: "",
          leader: "",
          members: "",
          approval_time: "",
          evaluate_unit: "",
          status: "0",
        },
        changeForm: {
          class_name: "",
          level: "",
          leader: "",
          members: "",
          approval_time: "",
          evaluate_unit: "",
          status: "",
        },
        statusArr:[
          this.$t("未审核"),
          this.$t("审核通过"),
        ],
        changeData: [],
        size: 0,
        data: [],
        isOpen: false,
        number: "",
        scopeNumber: "",
        right: localStorage.getItem("right"),
        enteringDialogVisible: false,
        changeDialogVisible: false,
        deleteDialogVisible: false,
        enteringLoading: false,
        changeLoading: false,
        deleteLoading: false
      };
    },
    created() {
      this.perfectCourseList();
    },
    methods: {
      detail(val) {
        this.isOpen = !this.isOpen;
        this.number = val;
      },
      perfectCourseList() {
        studentApi
          .perfectCourseList(this.filter)
          .then(data => {
            this.data = data.list;
            this.size = data.size;
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
      courseApplyConfirm() {
        this.enteringLoading = true;
        studentApi
          .courseApplyConfirm(this.form)
          .then(data => {
            this.enteringLoading = false;
            this.enteringDialogVisible = false;
            this.$message.success(this.$t("申请成功"));
            this.perfectCourseList();
          })
          .catch(e => {
            this.enteringLoading = false;
            this.$message.error(this.$t(e));
          });
      },
      courseAuditShow(number) {
        this.changeDialogVisible = true;
        studentApi
          .courseAuditShow({perfect_course_number: number})
          .then(data => {
            this.changeForm = data;
          })
          .catch(e => {
            this.$message.error(this.$t(e));
          });
      },
      courseAuditConfirm() {
        this.changeLoading = true;
        studentApi
          .courseAuditConfirm(this.changeForm)
          .then(data => {
            this.changeLoading = false;
            this.changeDialogVisible = false;
            this.$message.success(this.$t("审核成功"));
            this.perfectCourseList();
          })
          .catch(e => {
            this.changeLoading = false;
            this.$message.error(this.$t(e));
          });
      },
      clearData() {
        this.form = {
          class_name: "",
            level: "",
            leader: "",
            members: "",
            approval_time: "",
            evaluate_unit: "",
            status: "0",
        }
      },
      // cancel(val) {
      //   this.deleteDialogVisible = true;
      //   this.scopeNumber = val;
      // },
      // isCancel() {
      //   this.deleteLoading = true;
      //   studentApi
      //     .isCancel({number: this.scopeNumber})
      //     .then(data => {
      //       this.deleteLoading = false;
      //       this.deleteDialogVisible = false;
      //       this.$message.success(this.$t("删除成功"));
      //       this.perfectCourseList();
      //     })
      //     .catch(e => {
      //       this.deleteLoading = false;
      //       this.$message.error(this.$t(e));
      //     });
      // },
      filterM() {
        this.filter.currPage = 1;
        this.perfectCourseList();
      },
      reset() {
        this.filter = {
          pageSize: 10,
          currPage: 1,
          class_name: "",
          level: "",
          leader: "",
          status: "",
        };
        this.perfectCourseList();
      },
      pageChange(val) {
        this.filter.currPage = val;
        this.perfectCourseList();
      }
    }
  };
</script>

<style scoped lang="scss">
    .perfect-course {
        height: 100%;
        display: flex;
        flex-direction: column;

        .text-center {
            text-align: center;
        }

        .el-input {
            width: 150px;
        }

        .el-select {
            width: 150px;
        }

        .search {
            .header {
                display: flex;
                background: whitesmoke;
                border: 1px solid #e3e3e3;
                border-bottom: 1px solid whitesmoke;

                .title {
                    flex-grow: 1;
                }

                i {
                    padding: 20px 5px 20px 20px;
                }

                span {
                    padding: 20px 20px 20px 0;
                }

                .confirm,
                .reset {
                    color: teal;
                    cursor: pointer;
                }
            }

            .el-form {
                border: 1px solid #f3f3f3;
                padding: 20px;
            }
        }

        .main {
            flex-grow: 1;
            padding: 20px 0 60px;

            .el-button {
                margin: 5px;
            }
        }

        .footer {
            position: relative;

            .el-pagination {
                position: absolute;
                right: 0;
                bottom: 10px;
            }
        }

        .enteringResult,
        .changeResult {

            /deep/ {

                .el-dialog__body {
                    height: 200px;

                    .el-form {
                        padding-left: 40px;

                        .el-form-item {
                            float: left;
                            width: 300px;
                        }
                    }
                }
            }
        }
    }
</style>
